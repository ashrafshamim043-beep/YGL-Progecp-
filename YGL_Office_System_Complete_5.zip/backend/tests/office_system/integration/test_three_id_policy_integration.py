"""
Cross-module integration tests for the "3-Account Policy" Business
Decision -- proves, using the REAL frozen Commission Engine (not a
re-implementation), that three Member IDs linked to the same
MasterKYCIdentity have genuinely independent Sponsor positions and
Commission tracking (tests #10, #11, #12 from the Business Decision's
required list).
"""
import unittest
from decimal import Decimal
from datetime import datetime, timezone

import app.services.commission_service  # sys.path side-effect, see other integration tests

from commission_engine.approved_plan import build_approved_plan_v1
from commission_engine.models import Order, AccountStatus
from commission_engine.tree import InMemoryUplineProvider
from commission_engine.models import Member as EngineMember
from commission_engine.rank import InMemoryRankSnapshotProvider
from commission_engine.idempotency import IdempotencyStore
from commission_engine.undistributed import UndistributedFundTracker
from commission_engine.ledger import ImmutableLedger
from commission_engine.engine import CommissionEngine
from commission_engine.genealogy import GenealogyEngine, InMemoryMemberDirectory, MemberDirectoryEntry, MemberRole

from app.modules.identity_kyc.core import (
    DocumentType, InMemoryMasterKYCIdentityRepository, InMemoryMemberIdentityLinkRepository,
    InMemoryAccountKYCRepository,
)
from app.modules.identity_kyc.service import IdentityKYCService
from app.modules.member.core import InMemoryMemberRepository, InMemoryMemberStatusHistoryRepository
from app.modules.member.service import MemberService

NOW = datetime(2026, 9, 1, tzinfo=timezone.utc)


class TestThreeLinkedIdsIndependentGenealogy(unittest.TestCase):
    """Test #12: three Member IDs under the same identity can have
    completely different Sponsor positions -- proven with the real
    GenealogyEngine, not a mock."""

    def test_three_ids_placed_under_different_sponsors(self):
        directory = InMemoryMemberDirectory()
        for mid in ["root", "sponsor-a", "sponsor-b", "mofiz-id-1", "mofiz-id-2", "mofiz-id-3"]:
            directory.add(MemberDirectoryEntry(mid, MemberRole.MEMBER, AccountStatus.ACTIVE))
        genealogy = GenealogyEngine(directory)
        genealogy.place_member("root", None, NOW)
        genealogy.place_member("sponsor-a", "root", NOW)
        genealogy.place_member("sponsor-b", "root", NOW)

        # Same real-world person (Mofiz), 3 Member IDs, 3 DIFFERENT sponsors.
        p1 = genealogy.place_member("mofiz-id-1", "sponsor-a", NOW)
        p2 = genealogy.place_member("mofiz-id-2", "sponsor-b", NOW)
        p3 = genealogy.place_member("mofiz-id-3", "root", NOW)

        self.assertEqual(p1.sponsor_id, "sponsor-a")
        self.assertEqual(p2.sponsor_id, "sponsor-b")
        self.assertEqual(p3.sponsor_id, "root")
        self.assertNotEqual(p1.sponsor_id, p2.sponsor_id)


class TestThreeLinkedIdsIndependentCommission(unittest.TestCase):
    """Tests #10, #11: three Member IDs under the same identity earn and
    hold commission COMPLETELY independently -- proven with the real,
    frozen CommissionEngine + ImmutableLedger."""

    def test_three_ids_have_independent_ledger_balances_from_separate_orders(self):
        plan = build_approved_plan_v1()
        # mofiz-id-1 sponsors mofiz-id-2 sponsors mofiz-id-3 (a chain, to
        # also prove commission doesn't cross-contaminate even when the
        # SAME real person is both a buyer and an upline sponsor across
        # their own 3 IDs).
        tree = InMemoryUplineProvider(
            {"mofiz-id-2": "mofiz-id-1", "mofiz-id-3": "mofiz-id-2"},
            {
                "mofiz-id-1": EngineMember("mofiz-id-1", AccountStatus.ACTIVE),
                "mofiz-id-2": EngineMember("mofiz-id-2", AccountStatus.ACTIVE),
            },
        )
        ledger = ImmutableLedger()
        engine = CommissionEngine(
            plan, tree, InMemoryRankSnapshotProvider({}), IdempotencyStore(), UndistributedFundTracker(), ledger,
        )

        # mofiz-id-3 makes a purchase -- commission flows to mofiz-id-2 (direct
        # referral) and mofiz-id-1 (unilevel gen 2), per the real Engine's math.
        order = Order("INT-3ID-ORDER-1", "mofiz-id-3", Decimal("1000.00"), True, True, NOW)
        result = engine.process_order_payment_confirmed(order, "2026-09", 2026)
        for li in result.line_items:
            engine.approve_and_credit(li)

        balance_1 = ledger.balance_of("mofiz-id-1")
        balance_2 = ledger.balance_of("mofiz-id-2")
        balance_3 = ledger.balance_of("mofiz-id-3")

        # mofiz-id-3 (the buyer) earns personal-sales commission.
        self.assertEqual(balance_3, Decimal("70.00"))
        # mofiz-id-2 (direct sponsor) earns direct-referral + unilevel gen1.
        self.assertEqual(balance_2, Decimal("90.00"))
        # mofiz-id-1 (gen-2 upline) earns only the smaller unilevel gen-2 share.
        self.assertGreater(balance_1, Decimal("0.00"))
        self.assertLess(balance_1, balance_2)  # strictly less -- proves NO crossover/duplication
        # None of the three balances are equal -- proves independent tracking,
        # not a single shared/summed balance.
        self.assertNotEqual(balance_1, balance_2)
        self.assertNotEqual(balance_2, balance_3)


class TestFullAccountKycToIndependentActivation(unittest.TestCase):
    """End-to-end: three Member registrations, same NID, Account-KYC'd
    one at a time -- all three genuinely reach ACTIVE independently."""

    def test_three_registrations_same_nid_all_independently_activated(self):
        member_service = MemberService(InMemoryMemberRepository(), InMemoryMemberStatusHistoryRepository())
        identity_service = IdentityKYCService(
            InMemoryMasterKYCIdentityRepository(), InMemoryMemberIdentityLinkRepository(),
            InMemoryAccountKYCRepository(), member_service,
        )
        shared_nid = "9999988888"
        member_ids = []
        for i in range(1, 4):
            reg = member_service.register(f"Mofiz {i}", f"mofiz{i}@ygl.example", "Password1!")
            identity_service.complete_account_kyc(
                reg.member.id, f"0170000000{i}", mobile_verified=True,
                document_type=DocumentType.NID, document_number=shared_nid,
            )
            member_ids.append(reg.member.id)

        for mid in member_ids:
            from app.modules.member.core import MemberAccountStatus
            self.assertEqual(member_service.get_profile(mid).account_status, MemberAccountStatus.ACTIVE)

        self.assertEqual(len(set(member_ids)), 3)  # three genuinely distinct Member IDs


if __name__ == "__main__":
    unittest.main()
