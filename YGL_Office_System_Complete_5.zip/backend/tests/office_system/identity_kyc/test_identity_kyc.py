"""
Identity KYC test suite -- Account KYC (mobile + NID-or-Birth-Registration)
and the 3-Member-ID-per-identity cap.
"""
import unittest

from app.modules.identity_kyc.core import (
    DocumentType, MAX_MEMBER_IDS_PER_IDENTITY,
    InMemoryMasterKYCIdentityRepository, InMemoryMemberIdentityLinkRepository,
    InMemoryAccountKYCRepository,
    MobileNotVerifiedError, InvalidDocumentTypeError,
    DuplicateAccountKYCError, MaxMemberIdentityLimitError,
)
from app.modules.identity_kyc.service import IdentityKYCService
from app.modules.member.core import (
    MemberAccountStatus, InMemoryMemberRepository, InMemoryMemberStatusHistoryRepository,
)
from app.modules.member.service import MemberService


def build_service():
    member_service = MemberService(InMemoryMemberRepository(), InMemoryMemberStatusHistoryRepository())
    identity_service = IdentityKYCService(
        InMemoryMasterKYCIdentityRepository(), InMemoryMemberIdentityLinkRepository(),
        InMemoryAccountKYCRepository(), member_service,
    )
    return identity_service, member_service


def register_member(member_service, suffix):
    return member_service.register(
        f"Mofiz {suffix}", f"mofiz{suffix}@ygl.example", "Password1!",
    ).member


class TestAccountKYCWithNID(unittest.TestCase):
    def test_nid_based_account_kyc_activates_member(self):
        identity_service, member_service = build_service()
        member = register_member(member_service, "1")
        self.assertEqual(member.account_status, MemberAccountStatus.PENDING)

        result = identity_service.complete_account_kyc(
            member.id, "01700000000", mobile_verified=True,
            document_type=DocumentType.NID, document_number="1234567890",
        )
        self.assertEqual(result.member_ids_linked_to_identity, 1)

        activated = member_service.get_profile(member.id)
        self.assertEqual(activated.account_status, MemberAccountStatus.ACTIVE)


class TestAccountKYCWithBirthRegistration(unittest.TestCase):
    def test_birth_registration_based_account_kyc_activates_member(self):
        identity_service, member_service = build_service()
        member = register_member(member_service, "1")

        identity_service.complete_account_kyc(
            member.id, "01700000000", mobile_verified=True,
            document_type=DocumentType.BIRTH_REGISTRATION, document_number="BR-9876543210",
        )
        activated = member_service.get_profile(member.id)
        self.assertEqual(activated.account_status, MemberAccountStatus.ACTIVE)


class TestActiveMemberCanPurchase(unittest.TestCase):
    def test_account_kyc_completion_means_active_which_permits_purchase(self):
        """No separate Commerce module exists yet -- per the Business
        Decision, ACTIVE status itself IS the purchase-eligibility signal
        ('ACTIVE Member Product দেখতে, Product Purchase করতে ... পারবে')."""
        identity_service, member_service = build_service()
        member = register_member(member_service, "1")
        identity_service.complete_account_kyc(
            member.id, "01700000000", mobile_verified=True,
            document_type=DocumentType.NID, document_number="1234567890",
        )
        self.assertEqual(member_service.get_profile(member.id).account_status, MemberAccountStatus.ACTIVE)


class TestMobileVerificationRequired(unittest.TestCase):
    def test_unverified_mobile_blocks_account_kyc_and_activation(self):
        identity_service, member_service = build_service()
        member = register_member(member_service, "1")
        with self.assertRaises(MobileNotVerifiedError):
            identity_service.complete_account_kyc(
                member.id, "01700000000", mobile_verified=False,
                document_type=DocumentType.NID, document_number="1234567890",
            )
        # Member must remain PENDING -- nothing partially applied.
        self.assertEqual(member_service.get_profile(member.id).account_status, MemberAccountStatus.PENDING)


class TestInvalidDocumentType(unittest.TestCase):
    def test_unrecognized_document_type_rejected(self):
        identity_service, member_service = build_service()
        member = register_member(member_service, "1")
        with self.assertRaises(InvalidDocumentTypeError):
            identity_service.complete_account_kyc(
                member.id, "01700000000", mobile_verified=True,
                document_type="PASSPORT", document_number="X123",
            )


class TestDuplicateAccountKYC(unittest.TestCase):
    def test_second_account_kyc_attempt_for_same_member_rejected(self):
        identity_service, member_service = build_service()
        member = register_member(member_service, "1")
        identity_service.complete_account_kyc(
            member.id, "01700000000", mobile_verified=True,
            document_type=DocumentType.NID, document_number="1234567890",
        )
        with self.assertRaises(DuplicateAccountKYCError):
            identity_service.complete_account_kyc(
                member.id, "01700000000", mobile_verified=True,
                document_type=DocumentType.NID, document_number="1234567890",
            )


class TestThreeMemberIdCap(unittest.TestCase):
    """Tests 6-9 from the Business Decision's required list."""

    SAME_NID = "1111122222"

    def test_1st_id_with_shared_nid_allowed(self):
        identity_service, member_service = build_service()
        m1 = register_member(member_service, "1")
        result = identity_service.complete_account_kyc(
            m1.id, "01700000001", mobile_verified=True,
            document_type=DocumentType.NID, document_number=self.SAME_NID,
        )
        self.assertEqual(result.member_ids_linked_to_identity, 1)

    def test_2nd_id_with_shared_nid_allowed(self):
        identity_service, member_service = build_service()
        m1 = register_member(member_service, "1")
        m2 = register_member(member_service, "2")
        identity_service.complete_account_kyc(
            m1.id, "01700000001", mobile_verified=True,
            document_type=DocumentType.NID, document_number=self.SAME_NID,
        )
        result2 = identity_service.complete_account_kyc(
            m2.id, "01700000002", mobile_verified=True,
            document_type=DocumentType.NID, document_number=self.SAME_NID,
        )
        self.assertEqual(result2.member_ids_linked_to_identity, 2)
        self.assertEqual(member_service.get_profile(m2.id).account_status, MemberAccountStatus.ACTIVE)

    def test_3rd_id_with_shared_nid_allowed(self):
        identity_service, member_service = build_service()
        members = [register_member(member_service, str(i)) for i in range(1, 4)]
        for i, m in enumerate(members, start=1):
            result = identity_service.complete_account_kyc(
                m.id, f"0170000000{i}", mobile_verified=True,
                document_type=DocumentType.NID, document_number=self.SAME_NID,
            )
        self.assertEqual(result.member_ids_linked_to_identity, MAX_MEMBER_IDS_PER_IDENTITY)

    def test_4th_id_with_shared_nid_rejected(self):
        identity_service, member_service = build_service()
        members = [register_member(member_service, str(i)) for i in range(1, 5)]
        for i in range(3):
            identity_service.complete_account_kyc(
                members[i].id, f"0170000000{i}", mobile_verified=True,
                document_type=DocumentType.NID, document_number=self.SAME_NID,
            )
        fourth = members[3]
        with self.assertRaises(MaxMemberIdentityLimitError):
            identity_service.complete_account_kyc(
                fourth.id, "01700000009", mobile_verified=True,
                document_type=DocumentType.NID, document_number=self.SAME_NID,
            )
        # The 4th member must remain PENDING -- rejected cleanly, nothing applied.
        self.assertEqual(member_service.get_profile(fourth.id).account_status, MemberAccountStatus.PENDING)

    def test_different_nid_numbers_are_independent_identities_no_cap_interaction(self):
        """A cap on ONE identity must never affect a DIFFERENT identity."""
        identity_service, member_service = build_service()
        members_a = [register_member(member_service, f"a{i}") for i in range(1, 4)]
        for i, m in enumerate(members_a):
            identity_service.complete_account_kyc(
                m.id, f"017000000{i}", mobile_verified=True,
                document_type=DocumentType.NID, document_number="AAAA111111",
            )
        member_b = register_member(member_service, "b1")
        result_b = identity_service.complete_account_kyc(
            member_b.id, "01799999999", mobile_verified=True,
            document_type=DocumentType.NID, document_number="BBBB222222",  # different identity
        )
        self.assertEqual(result_b.member_ids_linked_to_identity, 1)  # not blocked by identity A's cap


if __name__ == "__main__":
    unittest.main()
