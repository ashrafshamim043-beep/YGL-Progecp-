"""
Withdrawal test suite -- proves Commission Earn / Commission Withdrawal
are genuinely independent (a non-zero ledger balance never bypasses the
Withdrawal-KYC gate), per Business Decision Section 2.
"""
import unittest
from decimal import Decimal

from app.modules.withdrawal.core import (
    WithdrawalKYCStatusValue, InMemoryWithdrawalKYCStatusRepository, InMemoryWithdrawalRequestRepository,
    WithdrawalKYCRequiredError, InsufficientBalanceError, InvalidWithdrawalAmountError,
)
from app.modules.withdrawal.service import WithdrawalService


def build_service(balances=None):
    balances = balances or {}
    kyc_repo = InMemoryWithdrawalKYCStatusRepository()
    request_repo = InMemoryWithdrawalRequestRepository()
    balance_provider = lambda member_id: balances.get(member_id, Decimal("0"))
    service = WithdrawalService(kyc_repo, request_repo, balance_provider)
    return service, kyc_repo, request_repo


class TestWithdrawalRequiresKYC(unittest.TestCase):
    def test_withdrawal_blocked_without_withdrawal_kyc_even_with_sufficient_balance(self):
        """The critical test: Commission Earn (a healthy ledger balance)
        must NEVER substitute for Withdrawal KYC completion."""
        service, kyc_repo, request_repo = build_service(balances={"member-1": Decimal("5000.00")})
        with self.assertRaises(WithdrawalKYCRequiredError):
            service.request_withdrawal("member-1", Decimal("100.00"))
        self.assertEqual(request_repo.list_for_member("member-1"), [])

    def test_withdrawal_succeeds_once_kyc_approved_and_balance_sufficient(self):
        service, kyc_repo, request_repo = build_service(balances={"member-1": Decimal("5000.00")})
        service.mark_withdrawal_kyc_approved("member-1")
        request = service.request_withdrawal("member-1", Decimal("100.00"))
        self.assertEqual(request.amount, Decimal("100.00"))
        self.assertEqual(request.status, "PENDING")


class TestInsufficientBalance(unittest.TestCase):
    def test_withdrawal_blocked_when_balance_too_low_even_with_kyc_approved(self):
        service, kyc_repo, request_repo = build_service(balances={"member-1": Decimal("50.00")})
        service.mark_withdrawal_kyc_approved("member-1")
        with self.assertRaises(InsufficientBalanceError) as ctx:
            service.request_withdrawal("member-1", Decimal("100.00"))
        self.assertEqual(ctx.exception.available, Decimal("50.00"))

    def test_kyc_check_happens_before_balance_check(self):
        """Order matters -- a member with BOTH no KYC AND insufficient
        balance must see the KYC error, not a confusing balance error."""
        service, kyc_repo, request_repo = build_service(balances={"member-1": Decimal("0.00")})
        with self.assertRaises(WithdrawalKYCRequiredError):
            service.request_withdrawal("member-1", Decimal("100.00"))


class TestInvalidAmount(unittest.TestCase):
    def test_zero_amount_rejected(self):
        service, kyc_repo, request_repo = build_service(balances={"member-1": Decimal("5000.00")})
        service.mark_withdrawal_kyc_approved("member-1")
        with self.assertRaises(InvalidWithdrawalAmountError):
            service.request_withdrawal("member-1", Decimal("0"))

    def test_negative_amount_rejected(self):
        service, kyc_repo, request_repo = build_service(balances={"member-1": Decimal("5000.00")})
        service.mark_withdrawal_kyc_approved("member-1")
        with self.assertRaises(InvalidWithdrawalAmountError):
            service.request_withdrawal("member-1", Decimal("-50.00"))


class TestEarnVsWithdrawalIndependence(unittest.TestCase):
    def test_default_kyc_status_is_not_started_never_implicitly_approved(self):
        service, kyc_repo, request_repo = build_service()
        status = kyc_repo.get_for_member("brand-new-member")
        self.assertEqual(status.status, WithdrawalKYCStatusValue.NOT_STARTED)


if __name__ == "__main__":
    unittest.main()
