"""
Sponsor core domain logic. Pure Python (no FastAPI/SQLAlchemy import here,
and NO commission_engine import here either -- that boundary is
exclusively app/services/commission_service/genealogy_facade.py).

Repository interfaces model exactly the sponsor_placements/
placement_review_queue schema already delivered (Phase 8.1), so the
DB-backed adapter (not built in this session) will be a direct, lossless
mapping -- same discipline as every other module in this system.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import datetime
from typing import Dict, List, Optional


# ---------------------------------------------------------------------------
# Domain records (field-for-field mirrors of commission_engine.genealogy's
# SponsorPlacement / PlacementReviewRequest, per the existing db_models.py
# docstring's own stated design intent)
# ---------------------------------------------------------------------------

@dataclass
class SponsorPlacementRecord:
    placement_id: str
    member_id: str
    sponsor_id: Optional[str]
    effective_from: datetime
    effective_to: Optional[datetime]
    placement_type: str  # INITIAL / RE_SPONSORSHIP / ADMIN_CORRECTION
    placement_reason: str
    created_by: str
    created_at: datetime


@dataclass
class PlacementReviewRecord:
    review_id: str
    member_id: str
    attempted_sponsor_id: str
    status: str  # PENDING / APPROVED / REJECTED
    attempted_at: datetime
    reviewed_by: Optional[str] = None
    reviewed_at: Optional[datetime] = None
    decision_reason: Optional[str] = None


# ---------------------------------------------------------------------------
# Exceptions (Office-System-level; GenealogyFacade's re-exported Engine
# exceptions -- SelfSponsorshipError etc. -- propagate through SponsorService
# unmodified, these are additive, not replacements)
# ---------------------------------------------------------------------------

class SponsorNotEligibleError(Exception):
    """Raised when a chosen sponsor's account is not ACTIVE -- an
    Office-System-level check performed BEFORE calling into
    GenealogyFacade, so an inactive-sponsor rejection is reported clearly
    rather than surfacing as a generic Engine validation failure."""


# ---------------------------------------------------------------------------
# Repository interfaces
# ---------------------------------------------------------------------------

class SponsorPlacementRepository(ABC):
    @abstractmethod
    def save(self, placement: SponsorPlacementRecord) -> None:
        raise NotImplementedError

    @abstractmethod
    def list_all(self) -> List[SponsorPlacementRecord]:
        """Every placement ever recorded -- used to rebuild a
        GenealogyFacade's internal state before each operation."""
        raise NotImplementedError

    @abstractmethod
    def list_for_member(self, member_id: str) -> List[SponsorPlacementRecord]:
        raise NotImplementedError


class PlacementReviewRepository(ABC):
    @abstractmethod
    def save(self, review: PlacementReviewRecord) -> None:
        raise NotImplementedError

    @abstractmethod
    def get_by_id(self, review_id: str) -> Optional[PlacementReviewRecord]:
        raise NotImplementedError

    @abstractmethod
    def list_pending(self) -> List[PlacementReviewRecord]:
        raise NotImplementedError


# ---------------------------------------------------------------------------
# In-memory implementations (testing)
# ---------------------------------------------------------------------------

class InMemorySponsorPlacementRepository(SponsorPlacementRepository):
    def __init__(self):
        self._records: List[SponsorPlacementRecord] = []

    def save(self, placement: SponsorPlacementRecord) -> None:
        self._records.append(placement)

    def list_all(self) -> List[SponsorPlacementRecord]:
        return list(self._records)

    def list_for_member(self, member_id: str) -> List[SponsorPlacementRecord]:
        return [r for r in self._records if r.member_id == member_id]


class InMemoryPlacementReviewRepository(PlacementReviewRepository):
    def __init__(self):
        self._by_id: Dict[str, PlacementReviewRecord] = {}

    def save(self, review: PlacementReviewRecord) -> None:
        self._by_id[review.review_id] = review

    def get_by_id(self, review_id: str) -> Optional[PlacementReviewRecord]:
        return self._by_id.get(review_id)

    def list_pending(self) -> List[PlacementReviewRecord]:
        return [r for r in self._by_id.values() if r.status == "PENDING"]
