"""
Sponsor Management models — the persistent backing for
commission_engine.genealogy.GenealogyEngine's in-memory _placements dict.

Column names deliberately mirror commission_engine.genealogy.SponsorPlacement
and PlacementReviewRequest field-for-field, so that loading a row into a
GenealogyEngine instance at request time is a direct, lossless mapping --
no translation layer that could silently drift from the Engine's own model.

This module NEVER re-implements placement validation (self-sponsorship,
circular-reference, suspended-sponsor checks, duplicate-placement routing).
All of that logic stays inside commission_engine.genealogy, imported only
by app/services/commission_service/ (see architecture boundary rule).
Sponsor Management's API layer constructs a GenealogyEngine from these rows
and calls its methods -- it does not duplicate their logic here.
"""
import uuid
from datetime import datetime

from sqlalchemy import String, DateTime, ForeignKey, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.db.session import Base


class SponsorPlacement(Base):
    __tablename__ = "sponsor_placements"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    member_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("members.id"), nullable=False)
    sponsor_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("members.id")
    )  # NULL only for the designated company ROOT
    effective_from: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    effective_to: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))  # NULL = currently active
    placement_type: Mapped[str] = mapped_column(String(32), nullable=False)  # INITIAL/RE_SPONSORSHIP/ADMIN_CORRECTION
    placement_reason: Mapped[str] = mapped_column(Text, nullable=False)
    created_by: Mapped[str] = mapped_column(String(255), nullable=False)  # "SELF" or a staff admin_id
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)

    # NOTE: append-only by convention here (no application-level UPDATE of
    # effective_to on an existing row's *content* other than closing it via
    # a controlled re_sponsor() flow that mirrors GenealogyEngine.re_sponsor()
    # exactly -- it never rewrites placement_type/sponsor_id/etc. in place).


class PlacementReviewQueue(Base):
    __tablename__ = "placement_review_queue"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    member_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("members.id"), nullable=False)
    attempted_sponsor_id: Mapped[str] = mapped_column(String(255), nullable=False)
    status: Mapped[str] = mapped_column(String(32), default="PENDING", nullable=False)  # PENDING/APPROVED/REJECTED
    attempted_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    reviewed_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("admins.id"))
    reviewed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    decision_reason: Mapped[str | None] = mapped_column(Text)
