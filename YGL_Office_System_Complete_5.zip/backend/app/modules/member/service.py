"""
MemberService -- registration, login, profile, and status-change
orchestration. Mirrors AuthService's structure closely (same
PasswordHasher, same dummy-hash timing-hardening on unknown email), but
is a SEPARATE service -- Members and Admins are different principals with
different lifecycles (KYC-gated activation, different status vocabulary)
and must not share a single service class.
"""
from __future__ import annotations

import uuid
from dataclasses import dataclass, replace
from datetime import datetime, timezone
from typing import Optional

from app.modules.member.core import (
    MemberAccount, MemberIdentity, MemberStatusChangeRecord,
    MemberRepository, MemberStatusHistoryRepository,
    MemberAccountStatus, validate_status_transition,
    EmailAlreadyRegisteredError, InvalidCredentialsError,
    MemberNotFoundError, AccountNotActiveError, InvalidStatusTransitionError,
)
from app.modules.auth.password_hashing import PasswordHasher, InvalidHashFormatError


@dataclass
class RegistrationResult:
    member: MemberAccount


@dataclass
class LoginResult:
    identity: MemberIdentity


class MemberService:
    def __init__(
        self,
        member_repo: MemberRepository,
        status_history_repo: MemberStatusHistoryRepository,
        password_hasher: Optional[PasswordHasher] = None,
    ):
        self.member_repo = member_repo
        self.status_history_repo = status_history_repo
        self.password_hasher = password_hasher or PasswordHasher()
        self._dummy_hash = self.password_hasher.hash_password("dummy-timing-hardening")

    # -- Registration ---------------------------------------------------

    def register(self, full_name: str, email: str, password: str, phone: Optional[str] = None) -> RegistrationResult:
        """
        New members start at PENDING (Office-System-only status -- see
        core.py's module docstring). They become ACTIVE only via KYC
        approval (already-built YGLKYCService.try_activate_member()), not
        through this method -- registration and activation are
        deliberately separate steps, never conflated.
        """
        if self.member_repo.get_by_email(email) is not None:
            raise EmailAlreadyRegisteredError(f"Email '{email}' is already registered.")
        if not password:
            raise ValueError("Password must not be empty.")

        now = datetime.now(timezone.utc)
        member = MemberAccount(
            id=str(uuid.uuid4()), full_name=full_name, email=email, phone=phone,
            password_hash=self.password_hasher.hash_password(password),
            account_status=MemberAccountStatus.PENDING,
            role="MEMBER", created_at=now,
        )
        self.member_repo.save(member)
        # No status_history row on registration -- PENDING is not an
        # Engine-recognized status and has no history entry by design
        # (mirrors how KYC's flow already works: the FIRST history row is
        # written only when KYC approval sets ACTIVE).
        return RegistrationResult(member=member)

    # -- Login ------------------------------------------------------------

    def login(self, email: str, password: str) -> LoginResult:
        """
        Raises InvalidCredentialsError (unknown email OR wrong password --
        deliberately indistinguishable, same rationale as AuthService),
        or AccountNotActiveError if credentials are correct but the
        account is PENDING/SUSPENDED/TERMINATED.
        """
        member = self.member_repo.get_by_email(email)
        if member is None:
            self.password_hasher.verify_password(password, self._dummy_hash)
            raise InvalidCredentialsError("Invalid email or password.")

        try:
            password_ok = self.password_hasher.verify_password(password, member.password_hash)
        except InvalidHashFormatError:
            password_ok = False

        if not password_ok:
            raise InvalidCredentialsError("Invalid email or password.")

        if member.account_status != MemberAccountStatus.ACTIVE:
            raise AccountNotActiveError(member.account_status)

        return LoginResult(identity=MemberIdentity(
            member_id=member.id, email=member.email, account_status=member.account_status,
        ))

    # -- Profile ------------------------------------------------------------

    def get_profile(self, member_id: str) -> MemberAccount:
        member = self.member_repo.get_by_id(member_id)
        if member is None:
            raise MemberNotFoundError(f"No member found with id {member_id}")
        return member

    def update_profile(self, member_id: str, full_name: Optional[str] = None,
                        phone: Optional[str] = None) -> MemberAccount:
        """Deliberately narrow: only full_name/phone are self-service
        editable here. email (login identity) and account_status (governed
        by KYC/admin actions) are NEVER changeable through this method."""
        member = self.member_repo.get_by_id(member_id)
        if member is None:
            raise MemberNotFoundError(f"No member found with id {member_id}")
        updated = replace(
            member,
            full_name=full_name if full_name is not None else member.full_name,
            phone=phone if phone is not None else member.phone,
        )
        self.member_repo.save(updated)
        return updated

    # -- Account KYC-driven activation (Business Decision: separate from
    # admin-driven change_status(), and separate from the older Sumsub-based
    # kyc/ module's activation path -- see identity_kyc/service.py) --------

    def activate_via_account_kyc(self, member_id: str, verified_by: str = "ACCOUNT_KYC_SERVICE") -> MemberAccount:
        """
        The ONLY legitimate way a Member moves PENDING -> ACTIVE under the
        new Business Decision (mobile + NID-or-Birth-Registration Account
        KYC). Called exclusively by identity_kyc.service.IdentityKYCService
        upon successful Account KYC completion -- never called directly by
        a router/admin action, and never used for any other transition
        (SUSPENDED/TERMINATED members are NOT reachable through this method).
        """
        member = self.member_repo.get_by_id(member_id)
        if member is None:
            raise MemberNotFoundError(f"No member found with id {member_id}")
        validate_status_transition(member.account_status, MemberAccountStatus.ACTIVE)

        now = datetime.now(timezone.utc)
        previous_status = member.account_status
        updated = replace(member, account_status=MemberAccountStatus.ACTIVE)
        self.member_repo.save(updated)
        self.status_history_repo.append(MemberStatusChangeRecord(
            id=str(uuid.uuid4()), member_id=member_id,
            from_status=previous_status, to_status=MemberAccountStatus.ACTIVE,
            changed_by=verified_by, reason="Account KYC completed", timestamp=now,
        ))
        return updated

    # -- Status management (Admin-driven: suspend/reinstate/terminate) ------

    def change_status(self, member_id: str, new_status: str, changed_by: str,
                       reason: Optional[str] = None) -> MemberAccount:
        """
        Admin-driven status change (suspend, reinstate, terminate). This is
        NOT how a member reaches ACTIVE for the first time -- that is
        exclusively KYC's job (try_activate_member()). This method's valid
        target-from-PENDING is limited to TERMINATED (e.g. an admin
        rejecting/closing a registration before KYC even starts) --
        PENDING -> ACTIVE via *this* method is intentionally blocked
        (see core.py's transition table: PENDING allows {ACTIVE, TERMINATED},
        but this method itself should be the KYC-bypass guard).
        """
        member = self.member_repo.get_by_id(member_id)
        if member is None:
            raise MemberNotFoundError(f"No member found with id {member_id}")
        if member.account_status == MemberAccountStatus.PENDING and new_status == MemberAccountStatus.ACTIVE:
            raise InvalidStatusTransitionError(
                "PENDING -> ACTIVE must go through KYC approval (YGLKYCService), "
                "not through admin-driven change_status()."
            )
        validate_status_transition(member.account_status, new_status)

        now = datetime.now(timezone.utc)
        previous_status = member.account_status
        updated = replace(member, account_status=new_status)
        self.member_repo.save(updated)
        self.status_history_repo.append(MemberStatusChangeRecord(
            id=str(uuid.uuid4()), member_id=member_id,
            from_status=previous_status, to_status=new_status,
            changed_by=changed_by, reason=reason, timestamp=now,
        ))
        return updated
