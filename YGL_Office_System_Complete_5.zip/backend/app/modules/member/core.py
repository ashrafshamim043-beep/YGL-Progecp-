"""
Member core domain logic. Pure Python (no FastAPI/SQLAlchemy import here) --
same pattern as auth/core.py and kyc/core.py: abstract repository
interfaces + in-memory implementations for tests, DB-backed adapters
plugged in separately for production.

Account status vocabulary note (important, flagged not silently decided):
commission_engine.models.AccountStatus recognizes exactly three values --
ACTIVE, SUSPENDED, TERMINATED (confirmed by direct import of the frozen
Engine). It has no "pending/unverified" concept. This module therefore
uses a FOURTH, Office-System-only status, "PENDING", for a member who has
registered but not yet completed KYC -- this value is NEVER written to
commission_engine's AccountStatus or passed to the Engine in any form; a
PENDING member simply has no member_status_history row yet (consistent
with how the KYC integration already behaves -- the first status-history
row, ACTIVE, is created only on KYC approval). Once KYC approves, the
member moves to ACTIVE, which IS one of the Engine's three real values.
This is a technical default proposed here, not a business rule invented
in secret -- BUSINESS OWNER CONFIRMATION recommended before production use
(e.g. should a member be allowed to browse/order before KYC completes?
Out of this module's scope to decide).
"""
from __future__ import annotations

import uuid
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional, Dict, List

# Reused, not duplicated -- same password-hashing primitive Auth already
# uses and has 27 tests proving correct. Members and Admins are different
# principals but there is no reason to invent a second hashing scheme.
from app.modules.auth.password_hashing import PasswordHasher, InvalidHashFormatError


# ---------------------------------------------------------------------------
# Account status vocabulary
# ---------------------------------------------------------------------------

class MemberAccountStatus:
    PENDING = "PENDING"        # Office-System-only, pre-KYC. Never sent to Commission Engine.
    ACTIVE = "ACTIVE"          # Commission-Engine-recognized.
    SUSPENDED = "SUSPENDED"    # Commission-Engine-recognized.
    TERMINATED = "TERMINATED"  # Commission-Engine-recognized.

    ENGINE_RECOGNIZED = {ACTIVE, SUSPENDED, TERMINATED}


_ALLOWED_STATUS_TRANSITIONS: Dict[str, set] = {
    MemberAccountStatus.PENDING: {MemberAccountStatus.ACTIVE, MemberAccountStatus.TERMINATED},
    MemberAccountStatus.ACTIVE: {MemberAccountStatus.SUSPENDED, MemberAccountStatus.TERMINATED},
    MemberAccountStatus.SUSPENDED: {MemberAccountStatus.ACTIVE, MemberAccountStatus.TERMINATED},
    MemberAccountStatus.TERMINATED: set(),  # terminal, no way back (mirrors a real "closed account")
}


class InvalidStatusTransitionError(Exception):
    pass


def validate_status_transition(from_status: str, to_status: str) -> None:
    allowed = _ALLOWED_STATUS_TRANSITIONS.get(from_status, set())
    if to_status not in allowed:
        raise InvalidStatusTransitionError(
            f"Transition {from_status} -> {to_status} is not allowed. "
            f"Allowed from {from_status}: {sorted(allowed) or '(none, terminal)'}"
        )


# ---------------------------------------------------------------------------
# Domain records
# ---------------------------------------------------------------------------

@dataclass
class MemberAccount:
    id: str
    full_name: str
    email: str
    phone: Optional[str]
    password_hash: str
    account_status: str
    role: str = "MEMBER"  # mirrors commission_engine.genealogy.MemberRole
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


@dataclass(frozen=True)
class MemberIdentity:
    """Output of successful member authentication -- deliberately minimal,
    mirrors AdminIdentity's shape for consistency (a future RBAC-for-members
    layer, if ever built, would consume this the same way)."""
    member_id: str
    email: str
    account_status: str


@dataclass
class MemberStatusChangeRecord:
    id: str
    member_id: str
    from_status: Optional[str]
    to_status: str
    changed_by: Optional[str]  # admin_id, or None for system/self-driven changes
    reason: Optional[str]
    timestamp: datetime


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------

class EmailAlreadyRegisteredError(Exception):
    pass


class InvalidCredentialsError(Exception):
    """Deliberately the same message for 'unknown email' and 'wrong
    password' -- see auth/service.py's identical rationale."""


class MemberNotFoundError(Exception):
    pass


class AccountNotActiveError(Exception):
    """Raised when a login is attempted against a PENDING/SUSPENDED/
    TERMINATED account. Message intentionally includes the status (unlike
    InvalidCredentialsError) because -- unlike Admin login -- a Member
    account existing-but-inactive is not itself sensitive information;
    the member already knows their own account exists."""
    def __init__(self, status: str):
        self.status = status
        super().__init__(f"Account is not active (status={status}).")


# ---------------------------------------------------------------------------
# Repository interfaces
# ---------------------------------------------------------------------------

class MemberRepository(ABC):
    @abstractmethod
    def get_by_email(self, email: str) -> Optional[MemberAccount]:
        raise NotImplementedError

    @abstractmethod
    def get_by_id(self, member_id: str) -> Optional[MemberAccount]:
        raise NotImplementedError

    @abstractmethod
    def save(self, member: MemberAccount) -> None:
        raise NotImplementedError


class MemberStatusHistoryRepository(ABC):
    @abstractmethod
    def append(self, record: MemberStatusChangeRecord) -> None:
        """Append-only -- no update()/delete(), same discipline as
        kyc_state_transitions and every other historical-fact table in
        this system."""
        raise NotImplementedError

    @abstractmethod
    def list_for_member(self, member_id: str) -> List[MemberStatusChangeRecord]:
        raise NotImplementedError


# ---------------------------------------------------------------------------
# In-memory implementations (testing)
# ---------------------------------------------------------------------------

class InMemoryMemberRepository(MemberRepository):
    def __init__(self):
        self._by_id: Dict[str, MemberAccount] = {}

    def get_by_email(self, email: str) -> Optional[MemberAccount]:
        for m in self._by_id.values():
            if m.email == email:
                return m
        return None

    def get_by_id(self, member_id: str) -> Optional[MemberAccount]:
        return self._by_id.get(member_id)

    def save(self, member: MemberAccount) -> None:
        self._by_id[member.id] = member


class InMemoryMemberStatusHistoryRepository(MemberStatusHistoryRepository):
    def __init__(self):
        self._records: List[MemberStatusChangeRecord] = []

    def append(self, record: MemberStatusChangeRecord) -> None:
        self._records.append(record)

    def list_for_member(self, member_id: str) -> List[MemberStatusChangeRecord]:
        return [r for r in self._records if r.member_id == member_id]
