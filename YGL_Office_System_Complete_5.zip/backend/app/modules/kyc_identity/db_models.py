"""
KYCIdentity persistence model. Additive-only schema addition -- does NOT
modify any existing table's columns/behavior. Member's own table gets one
NEW, nullable FK column (see member/db_models.py note below) so max-3
enforcement can be verified directly against real data (count of Members
referencing a given kyc_identity_id).
"""
import uuid
from datetime import datetime

from sqlalchemy import String, DateTime, UniqueConstraint, func
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.db.session import Base


class KYCIdentityRow(Base):
    __tablename__ = "kyc_identities"
    __table_args__ = (
        # A given (document_type, normalized_document_number) pair maps to
        # exactly ONE KYCIdentity -- this IS the mechanism that makes "same
        # document -> same identity" enforceable at the DB level, not just
        # in application code.
        UniqueConstraint("document_type", "normalized_document_number",
                          name="uq_kyc_identities_document"),
    )

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    document_type: Mapped[str] = mapped_column(String(32), nullable=False)  # NID / BIRTH_REGISTRATION
    normalized_document_number: Mapped[str] = mapped_column(String(64), nullable=False)
    mobile_number: Mapped[str] = mapped_column(String(32), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    # NOTE: linked_member_ids is NOT a column here -- it is derived by
    # querying members WHERE kyc_identity_id = this row's id (see
    # member/db_models.py's new column). This avoids storing a redundant,
    # potentially-inconsistent duplicate list.
