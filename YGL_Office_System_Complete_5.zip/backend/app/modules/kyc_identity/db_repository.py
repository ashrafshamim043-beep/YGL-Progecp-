"""
SQLAlchemy-backed KYCIdentityRepository -- implements the SAME interface
(kyc_identity/core.py) that InMemoryKYCIdentityRepository already
implements and that this module's 11 tests already prove correct. Adds
no new max-3-enforcement LOGIC -- that lives entirely in core.py's
link_member_to_identity(), unchanged; this file only persists/loads the
same KYCIdentity shape.
"""
import uuid
from typing import Optional

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.modules.kyc_identity.core import KYCIdentity, KYCIdentityRepository
from app.modules.kyc_identity.db_models import KYCIdentityRow
from app.modules.member.db_models import Member


class SQLAlchemyKYCIdentityRepository(KYCIdentityRepository):
    def __init__(self, db: Session):
        self.db = db

    def _row_to_domain(self, row: Optional[KYCIdentityRow]) -> Optional[KYCIdentity]:
        if row is None:
            return None
        linked_ids = self.db.execute(
            select(Member.id).where(Member.kyc_identity_id == row.id)
        ).scalars().all()
        return KYCIdentity(
            id=str(row.id), document_type=row.document_type,
            normalized_document_number=row.normalized_document_number,
            mobile_number=row.mobile_number,
            linked_member_ids=[str(m) for m in linked_ids],
            created_at=row.created_at,
        )

    def get_by_document(self, document_type: str, normalized_document_number: str) -> Optional[KYCIdentity]:
        stmt = select(KYCIdentityRow).where(
            KYCIdentityRow.document_type == document_type,
            KYCIdentityRow.normalized_document_number == normalized_document_number,
        )
        row = self.db.execute(stmt).scalar_one_or_none()
        return self._row_to_domain(row)

    def get_by_document_locked(self, document_type: str, normalized_document_number: str) -> Optional[KYCIdentity]:
        """
        CONCURRENCY-CRITICAL: identical to get_by_document(), but acquires
        a row-level lock (SELECT ... FOR UPDATE) on the KYCIdentityRow
        first, when one already exists. This is what makes the 4th-ID
        race condition (two requests both reading "2 linked members,
        space for a 3rd" concurrently, both proceeding) impossible at the
        DB level: the SECOND concurrent transaction blocks until the
        FIRST commits or rolls back, then re-reads the now-correct,
        already-updated member count. The caller (AccountKYCService, via
        this repository) must call this method -- not the plain
        get_by_document() -- inside a real transaction for the
        concurrency guarantee to hold; this is documented at the call
        site in service.py.
        """
        stmt = select(KYCIdentityRow).where(
            KYCIdentityRow.document_type == document_type,
            KYCIdentityRow.normalized_document_number == normalized_document_number,
        ).with_for_update()
        row = self.db.execute(stmt).scalar_one_or_none()
        return self._row_to_domain(row)

    def get_by_id(self, identity_id: str) -> Optional[KYCIdentity]:
        row = self.db.get(KYCIdentityRow, uuid.UUID(identity_id))
        return self._row_to_domain(row)

    def save(self, identity: KYCIdentity) -> None:
        """
        Persists the KYCIdentity row itself, AND -- critically -- sets
        members.kyc_identity_id for every member_id in
        identity.linked_member_ids (this is how "linked_member_ids" is
        actually represented in the real schema: a reverse FK, not a
        stored list column -- see kyc_identity/db_models.py's docstring).
        """
        row = self.db.get(KYCIdentityRow, uuid.UUID(identity.id))
        if row is None:
            row = KYCIdentityRow(
                id=uuid.UUID(identity.id), document_type=identity.document_type,
                normalized_document_number=identity.normalized_document_number,
                mobile_number=identity.mobile_number,
            )
            self.db.add(row)
            self.db.flush()

        for member_id in identity.linked_member_ids:
            member = self.db.get(Member, uuid.UUID(member_id))
            if member is not None and member.kyc_identity_id != row.id:
                member.kyc_identity_id = row.id
        self.db.flush()
