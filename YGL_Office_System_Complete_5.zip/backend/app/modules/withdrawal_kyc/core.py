"""
Withdrawal KYC eligibility check -- per Business Decision, Commission
Withdrawal requires FULL KYC (Identity + NID/Birth-Reg + Face + Liveness +
Payment-account ownership + Fraud screening), which is EXACTLY what the
existing kyc/ module (Sumsub-based, 24 tests, already built) already
performs -- that module is re-scoped as the "Withdrawal KYC" tier by this
Business Decision, per the explicit note given alongside this
implementation. No new KYC verification logic is written here -- this
module ONLY re-reads the existing kyc/ module's KYCVerification state via
its own repository interface (reused, not duplicated) to answer one
question: "may this member withdraw right now?"

Payment-account/bank/MFS ownership verification and duplicate/fraud
screening are NOT modeled here -- those require a payment-provider
integration decision not yet made (mirrors how KYC's own
create_applicant()/get_verification_url() remain blocked pending
Production Vendor Approval). This module only checks the identity/face/
liveness portion that the existing kyc/ module already covers, and
explicitly flags the remaining gap rather than inventing a fake payment
check.
"""
from __future__ import annotations

from app.modules.kyc.core import KYCVerificationRepository, KYCState


class WithdrawalKYCRequiredError(Exception):
    """Raised when a withdrawal is attempted without a completed
    (APPROVED) Withdrawal KYC verification. Commission may still be
    EARNED and remain in the Ledger -- this error blocks WITHDRAWAL only,
    never earning/accrual (per Business Decision Section 2's explicit
    Earn-vs-Withdraw distinction)."""
    def __init__(self, member_id: str, current_state: str):
        self.member_id = member_id
        self.current_state = current_state
        super().__init__(
            f"Member '{member_id}' cannot withdraw commission -- Withdrawal KYC "
            f"is not APPROVED (current state: {current_state})."
        )


def is_withdrawal_eligible(kyc_verification_repo: KYCVerificationRepository, member_id: str) -> bool:
    """Returns True only if the member's most relevant KYC verification
    (via the EXISTING kyc/ module) has reached APPROVED. Any other state
    (PENDING, DOCUMENT_SUBMITTED, VERIFICATION_IN_PROGRESS, MANUAL_REVIEW,
    REJECTED, or no verification at all) means NOT eligible."""
    verification = kyc_verification_repo.get_active_for_member(member_id)
    return verification is not None and verification.state == KYCState.APPROVED


def require_withdrawal_eligible(kyc_verification_repo: KYCVerificationRepository, member_id: str) -> None:
    """Raises WithdrawalKYCRequiredError if not eligible; returns None
    (does nothing) if eligible. Callers (a future Commission-Withdrawal
    endpoint, not yet built) should call this BEFORE any withdrawal is
    processed -- Commission Ledger balance is irrelevant if this check fails."""
    verification = kyc_verification_repo.get_active_for_member(member_id)
    current_state = verification.state.value if verification is not None else "NO_VERIFICATION"
    if verification is None or verification.state != KYCState.APPROVED:
        raise WithdrawalKYCRequiredError(member_id, current_state)
