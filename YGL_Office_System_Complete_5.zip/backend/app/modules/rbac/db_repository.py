"""
SQLAlchemy-backed RolePermissionRepository -- queries the real roles/
permissions/role_permissions tables (seeded by migration
0003_rbac_permission_seed.py) instead of the in-memory constant. Adds no
new authorization LOGIC -- Step 2's 19 tests already prove the permission
matrix itself is correct; this file only changes WHERE that matrix is
read from.
"""
import uuid
from typing import Set

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.modules.rbac.core import RolePermissionRepository
from app.modules.identity.db_models import Role, Permission as PermissionRow, RolePermission


class SQLAlchemyRolePermissionRepository(RolePermissionRepository):
    """
    NOTE: `role_id` here is the role's UUID primary key (as stored on
    Admin.role_id), NOT the role's name string -- unlike
    InMemoryRolePermissionRepository (Step 2), which used the name
    directly for test simplicity. This adapter resolves the UUID to its
    permission-code set via a join, matching how the real `admins` table
    actually references roles.
    """

    def __init__(self, db: Session):
        self.db = db

    def get_permissions_for_role(self, role_id: str) -> Set[str]:
        try:
            role_uuid = uuid.UUID(role_id)
        except ValueError:
            return set()
        stmt = (
            select(PermissionRow.code)
            .join(RolePermission, RolePermission.permission_id == PermissionRow.id)
            .where(RolePermission.role_id == role_uuid)
        )
        rows = self.db.execute(stmt).scalars().all()
        return set(rows)

    def role_exists(self, role_id: str) -> bool:
        try:
            role_uuid = uuid.UUID(role_id)
        except ValueError:
            return False
        return self.db.get(Role, role_uuid) is not None
