"""
RBAC core domain logic. Pure Python, zero external dependencies -- same
pattern as auth/core.py and kyc/core.py.

Scope boundary (per Step 2's explicit authorization): permission-based
authorization only. The AuditLogWriter interface is REUSED from
kyc/core.py (imported, not duplicated, not modified) because it is
already a generic, provider-agnostic interface -- its DB-backed
implementation remains Step 3 scope; only an in-memory test double is
used here.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Dict, List, Optional, Set

# Reused, not duplicated: AuditLogWriter is already a generic interface in
# kyc/core.py. Importing it here does not modify kyc/core.py in any way.
from app.modules.kyc.core import AuditLogWriter, InMemoryAuditLogWriter  # noqa: F401 (re-exported for convenience)


# ---------------------------------------------------------------------------
# Permission codes -- "<resource>.<action>" naming convention
# ---------------------------------------------------------------------------
# Per Business Owner directive: only the permissions genuinely needed for
# Phase 8.2's current scope are seeded here. Future Commerce/Sponsor/
# Payment permissions follow the SAME naming convention but are NOT
# created yet (documented in this module's docstring only, not as code).

class Permission:
    MEMBER_READ = "member.read"
    MEMBER_WRITE = "member.write"
    COMMISSION_VIEW = "commission.view"
    COMMISSION_APPROVE = "commission.approve"
    LEDGER_VIEW = "ledger.view"
    ADJUSTMENT_REQUEST = "adjustment.request"
    ADJUSTMENT_APPROVE = "adjustment.approve"
    PLAN_VERSION_PUBLISH = "plan_version.publish"
    KYC_REVIEW = "kyc.review"
    AUDIT_LOG_READ = "audit_log.read"

    ALL = {
        MEMBER_READ, MEMBER_WRITE, COMMISSION_VIEW, COMMISSION_APPROVE,
        LEDGER_VIEW, ADJUSTMENT_REQUEST, ADJUSTMENT_APPROVE,
        PLAN_VERSION_PUBLISH, KYC_REVIEW, AUDIT_LOG_READ,
    }


# ---------------------------------------------------------------------------
# Role names
# ---------------------------------------------------------------------------

class RoleName:
    SUPER_ADMIN = "SUPER_ADMIN"
    FINANCE_ADMIN = "FINANCE_ADMIN"
    SUPPORT_ADMIN = "SUPPORT_ADMIN"
    COMPLIANCE_KYC_ADMIN = "COMPLIANCE_KYC_ADMIN"


# ---------------------------------------------------------------------------
# Final Role -> Permission matrix, EXACTLY per Business Owner's Final
# Decision (Step 2 authorization message). Nothing here was decided by
# this code -- every grant below traces directly to that message.
# ---------------------------------------------------------------------------
# NOTE on audit_log.read: the Business Owner's matrix qualifies Finance
# Admin's and Compliance/KYC Admin's audit_log.read as "financial-related
# scope" / "KYC-related scope" respectively. That CONTENT-level filtering
# (which specific audit_log rows a role may see) is a query-filtering
# concern for the audit-log READ endpoint's implementation -- which
# depends on the DB-backed audit log adapter, explicitly Step 3 scope, not
# Step 2's. This module only grants/denies the audit_log.read PERMISSION
# itself (a boolean yes/no), consistent with RBAC's binary nature; the
# scoping-by-category logic is intentionally NOT built here, to avoid
# inventing Step 3 functionality prematurely.
#
# NOTE on Support Admin / KYC status read-only: the Business Owner's design
# describes Support Admin as able to see KYC status read-only, but did NOT
# request a distinct new permission code for this (the seed list of 10
# codes has no kyc.read/kyc.view). member.read is interpreted here as
# already covering visibility of a member's own profile-level KYC status
# flag (e.g. account_status) -- no new permission code is invented.

_ROLE_PERMISSIONS: Dict[str, Set[str]] = {
    RoleName.SUPER_ADMIN: set(Permission.ALL),  # "সব বর্তমান permission"
    RoleName.FINANCE_ADMIN: {
        Permission.MEMBER_READ,
        Permission.COMMISSION_VIEW,
        Permission.COMMISSION_APPROVE,
        Permission.LEDGER_VIEW,
        Permission.ADJUSTMENT_REQUEST,
        Permission.AUDIT_LOG_READ,
    },
    RoleName.SUPPORT_ADMIN: {
        Permission.MEMBER_READ,
        Permission.MEMBER_WRITE,
        # Explicitly NOT kyc.review, NOT any financial-approval permission.
    },
    RoleName.COMPLIANCE_KYC_ADMIN: {
        Permission.MEMBER_READ,
        Permission.KYC_REVIEW,
        Permission.AUDIT_LOG_READ,
        # Explicitly NOT commission.approve/adjustment.approve/etc. --
        # "KYC review-এর সঙ্গে financial permission automatically দেওয়া
        # যাবে না" (Business Owner directive, verified by test).
    },
}


# ---------------------------------------------------------------------------
# Repository interface + in-memory implementation
# ---------------------------------------------------------------------------

class RolePermissionRepository(ABC):
    @abstractmethod
    def get_permissions_for_role(self, role_id: str) -> Set[str]:
        raise NotImplementedError

    @abstractmethod
    def role_exists(self, role_id: str) -> bool:
        raise NotImplementedError


class InMemoryRolePermissionRepository(RolePermissionRepository):
    """
    Seeded directly from _ROLE_PERMISSIONS above. Uses `role_id` as the
    role NAME in this in-memory implementation for simplicity (the
    DB-backed adapter, when built, resolves an actual UUID role_id to a
    role NAME via the `roles` table before doing this same set lookup --
    that indirection is a DB-adapter concern, not a core-logic one).

    Duplicate-assignment safety: internally backed by `set()` for every
    role -- assigning the same permission to a role multiple times (e.g.
    from a careless seed script) collapses naturally to a single grant,
    exactly mirroring the DB's own (role_id, permission_id) composite
    primary key guarantee on the real `role_permissions` table.
    """

    def __init__(self, role_permissions: Optional[Dict[str, Set[str]]] = None):
        # Defensive copy with explicit set() wrapping -- guards against a
        # caller accidentally passing a list with duplicates.
        source = role_permissions if role_permissions is not None else _ROLE_PERMISSIONS
        self._role_permissions: Dict[str, Set[str]] = {role: set(perms) for role, perms in source.items()}

    def get_permissions_for_role(self, role_id: str) -> Set[str]:
        return set(self._role_permissions.get(role_id, set()))

    def role_exists(self, role_id: str) -> bool:
        return role_id in self._role_permissions

    def grant_permission(self, role_id: str, permission: str) -> None:
        """Idempotent: granting an already-granted permission is a no-op,
        never a duplicate or an error (set semantics)."""
        self._role_permissions.setdefault(role_id, set()).add(permission)


def default_role_permission_repository() -> InMemoryRolePermissionRepository:
    """Returns a repository seeded with the exact, final Business Owner
    role matrix (_ROLE_PERMISSIONS above)."""
    return InMemoryRolePermissionRepository()


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------

class AuthorizationError(Exception):
    """Base class. Callers should generally catch the specific subclass
    (UnauthenticatedError -> 401, PermissionDeniedError -> 403), never
    this base class alone, to avoid conflating the two HTTP semantics."""


class UnauthenticatedError(AuthorizationError):
    """Maps to HTTP 401 -- missing, invalid, or expired credentials."""


class PermissionDeniedError(AuthorizationError):
    """Maps to HTTP 403 -- valid identity, but the required permission is
    not granted to this admin's role."""

    def __init__(self, admin_id: str, required_permission: str):
        self.admin_id = admin_id
        self.required_permission = required_permission
        # Deliberately generic message -- per Business Owner directive
        # ("sensitive information প্রকাশ করবে না"), this exception's
        # str() is safe to log internally but callers building an HTTP
        # response should return a generic "Forbidden" body, not this
        # message verbatim (which does reveal the permission name --
        # acceptable for internal logs/audit, NOT for the HTTP response
        # body; see service.py's docstring on this point).
        super().__init__(f"Admin '{admin_id}' lacks required permission '{required_permission}'.")
