"""
Minimal JWT (HS256) implementation -- RFC 7519 (JWT) + RFC 7515 (JWS,
compact serialization, HMAC-SHA256).

DESIGN NOTE (flagged): pyjwt is declared in pyproject.toml as the intended
production library, but cannot be installed in this offline sandbox. This
module implements the HS256 JWT compact-serialization format directly
against the Python standard library (hmac, hashlib, json, base64) --
producing/consuming tokens that are fully RFC-7519-compliant and
interoperable with pyjwt or any other standard JWT library. This is a
real implementation, not a mock, and is a drop-in-replaceable interface
if the team later prefers pyjwt (e.g. for RS256/other-algorithm support).

The JWT secret is NEVER hard-coded here or anywhere in this module -- it
must always be passed in by the caller, which in turn reads it from
app.core.config.settings.jwt_secret_key (itself sourced from environment/
secrets-manager, never committed).
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import time
from typing import Any, Dict, Optional


class InvalidTokenError(Exception):
    """Raised for any structurally invalid, unverifiable, or expired token.
    Deliberately a single exception type with a descriptive message rather
    than many subtypes -- callers must treat every failure mode as
    'reject the token', never selectively trust a partially-valid one."""


def _b64url_encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def _b64url_decode(data: str) -> bytes:
    padding = "=" * (-len(data) % 4)
    return base64.urlsafe_b64decode(data + padding)


def encode(payload: Dict[str, Any], secret: str, expires_in_seconds: Optional[int] = None) -> str:
    """
    Encodes `payload` as an HS256 JWT. If `expires_in_seconds` is given, an
    `exp` claim is added (or overwritten) automatically -- callers should
    not need to compute `exp` themselves, reducing the chance of an
    off-by-mistake unexpiring token.
    """
    if not secret:
        raise ValueError("JWT secret must not be empty -- refusing to sign with a blank key.")
    header = {"alg": "HS256", "typ": "JWT"}
    body = dict(payload)
    if expires_in_seconds is not None:
        body["exp"] = int(time.time()) + expires_in_seconds
    body.setdefault("iat", int(time.time()))

    header_b64 = _b64url_encode(json.dumps(header, separators=(",", ":")).encode("utf-8"))
    payload_b64 = _b64url_encode(json.dumps(body, separators=(",", ":")).encode("utf-8"))
    signing_input = f"{header_b64}.{payload_b64}".encode("ascii")
    signature = hmac.new(secret.encode("utf-8"), signing_input, hashlib.sha256).digest()
    signature_b64 = _b64url_encode(signature)
    return f"{header_b64}.{payload_b64}.{signature_b64}"


def decode(token: str, secret: str, verify_exp: bool = True) -> Dict[str, Any]:
    """
    Verifies signature (constant-time) and, unless verify_exp=False,
    rejects an expired token. Raises InvalidTokenError for ANY problem --
    malformed structure, wrong signature, unsupported algorithm, or
    expiry -- never returns a partially-trusted payload.
    """
    if not secret:
        raise ValueError("JWT secret must not be empty -- refusing to verify with a blank key.")
    try:
        header_b64, payload_b64, signature_b64 = token.split(".")
    except ValueError:
        raise InvalidTokenError("Token does not have the required three-part structure.")

    try:
        header = json.loads(_b64url_decode(header_b64))
    except (ValueError, UnicodeDecodeError) as e:
        raise InvalidTokenError(f"Malformed token header: {e}")

    if header.get("alg") != "HS256":
        raise InvalidTokenError(f"Unsupported or missing algorithm: {header.get('alg')!r}")

    signing_input = f"{header_b64}.{payload_b64}".encode("ascii")
    expected_signature = hmac.new(secret.encode("utf-8"), signing_input, hashlib.sha256).digest()
    try:
        actual_signature = _b64url_decode(signature_b64)
    except (ValueError, UnicodeDecodeError):
        raise InvalidTokenError("Malformed token signature.")

    if not hmac.compare_digest(expected_signature, actual_signature):
        raise InvalidTokenError("Signature verification failed.")

    try:
        payload = json.loads(_b64url_decode(payload_b64))
    except (ValueError, UnicodeDecodeError) as e:
        raise InvalidTokenError(f"Malformed token payload: {e}")

    if verify_exp and "exp" in payload:
        if int(time.time()) >= int(payload["exp"]):
            raise InvalidTokenError("Token has expired.")

    return payload
