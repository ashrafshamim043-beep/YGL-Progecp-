"""
Auth API router -- login, MFA, refresh-token endpoints. Wires HTTP
requests to AuthService (Step 1's already-tested logic); contains no
authentication logic of its own.
"""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Header
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.core.config import settings
from app.db.session import get_db
from app.modules.auth.core import (
    InvalidCredentialsError, AccountLockedError, AccountDisabledError,
    MfaRequiredError, InvalidMfaCodeError, MfaNotEnrolledError, RefreshTokenInvalidError,
)
from app.modules.auth.jwt_utils import InvalidTokenError
from app.modules.auth.service import AuthService, AuthConfig
from app.modules.auth.db_repositories import SQLAlchemyAdminRepository, SQLAlchemyRefreshTokenRepository

router = APIRouter()


def get_auth_service(db: Session = Depends(get_db)) -> AuthService:
    admin_repo = SQLAlchemyAdminRepository(db)
    refresh_repo = SQLAlchemyRefreshTokenRepository(db)
    config = AuthConfig(
        jwt_secret=settings.jwt_secret_key,
        access_token_ttl_seconds=settings.jwt_access_token_ttl_minutes * 60,
        refresh_token_ttl_seconds=settings.jwt_refresh_token_ttl_days * 24 * 60 * 60,
        login_failure_threshold=settings.admin_login_failure_threshold,
        lockout_duration_seconds=settings.admin_login_lockout_minutes * 60,
    )
    return AuthService(admin_repo, refresh_repo, config)


def get_current_admin_identity(
    authorization: str = Header(default=""),
    auth_service: AuthService = Depends(get_auth_service),
):
    """
    The dependency other routers (KYC, and future RBAC-protected routers)
    use to require authentication. Extracts a Bearer token from the
    Authorization header. Raises 401 for anything wrong with the token --
    RBAC's own PermissionDeniedError (403) is a SEPARATE, later check, not
    performed here.
    """
    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing or malformed Authorization header.")
    token = authorization[len("Bearer "):]
    try:
        return auth_service.get_identity_from_access_token(token)
    except InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid or expired token.")


# --- Request/response schemas -----------------------------------------------

class LoginRequest(BaseModel):
    email: str
    password: str


class MfaVerifyRequest(BaseModel):
    mfa_challenge_token: str
    totp_code: str


class RefreshRequest(BaseModel):
    refresh_token_id: str


class MfaConfirmRequest(BaseModel):
    totp_code: str


# --- Endpoints ----------------------------------------------------------

@router.post("/admin/login")
async def login(body: LoginRequest, auth_service: AuthService = Depends(get_auth_service)):
    try:
        result = auth_service.login(body.email, body.password)
        return {
            "access_token": result.access_token, "refresh_token_id": result.refresh_token_id,
            "admin_id": result.identity.admin_id, "role_id": result.identity.role_id,
        }
    except MfaRequiredError as e:
        # Per the design: no session token issued yet -- only a short-lived
        # MFA challenge token, which the client must submit to /mfa/verify.
        return {"mfa_required": True, "mfa_challenge_token": e.mfa_challenge_token}
    except (InvalidCredentialsError, AccountDisabledError):
        # Deliberately generic message for both -- never reveal which case.
        raise HTTPException(status_code=401, detail="Invalid email or password.")
    except AccountLockedError as e:
        raise HTTPException(status_code=423, detail=f"Account locked until {e.locked_until.isoformat()}.")


@router.post("/admin/mfa/verify")
async def verify_mfa(body: MfaVerifyRequest, auth_service: AuthService = Depends(get_auth_service)):
    try:
        result = auth_service.verify_mfa(body.mfa_challenge_token, body.totp_code)
        return {
            "access_token": result.access_token, "refresh_token_id": result.refresh_token_id,
            "admin_id": result.identity.admin_id, "role_id": result.identity.role_id,
        }
    except (InvalidMfaCodeError, MfaNotEnrolledError):
        raise HTTPException(status_code=401, detail="Invalid MFA code or challenge.")


@router.post("/admin/refresh")
async def refresh(body: RefreshRequest, auth_service: AuthService = Depends(get_auth_service)):
    try:
        result = auth_service.refresh_access_token(body.refresh_token_id)
        return {
            "access_token": result.access_token, "refresh_token_id": result.refresh_token_id,
        }
    except RefreshTokenInvalidError:
        raise HTTPException(status_code=401, detail="Refresh token is invalid, expired, or revoked.")


@router.post("/admin/mfa/enroll")
async def enroll_mfa(
    identity=Depends(get_current_admin_identity),
    auth_service: AuthService = Depends(get_auth_service),
):
    """Returns a base32 TOTP secret for the caller's authenticator app.
    MFA is NOT active until /admin/mfa/confirm succeeds."""
    secret = auth_service.enroll_mfa_start(identity.admin_id)
    return {"mfa_secret": secret}


@router.post("/admin/mfa/confirm")
async def confirm_mfa(
    body: MfaConfirmRequest,
    identity=Depends(get_current_admin_identity),
    auth_service: AuthService = Depends(get_auth_service),
):
    try:
        auth_service.confirm_mfa_enrollment(identity.admin_id, body.totp_code)
        return {"mfa_enrolled": True}
    except InvalidMfaCodeError:
        raise HTTPException(status_code=401, detail="Invalid TOTP code -- enrollment not activated.")
