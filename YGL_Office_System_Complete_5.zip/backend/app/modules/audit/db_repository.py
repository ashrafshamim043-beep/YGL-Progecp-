"""
Production, DB-backed AuditLogWriter -- implements the SAME interface
already defined in app/modules/kyc/core.py (AuditLogWriter). Reused, not
duplicated: RBAC and KYC both already depend on that interface; this file
is simply the real persistence adapter both of them plug into.
"""
import uuid
from datetime import datetime
from typing import Any, Dict, Optional

from sqlalchemy import String, DateTime, JSON, func
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy.orm import Mapped, mapped_column, Session

from app.db.session import Base
from app.modules.kyc.core import AuditLogWriter


class AuditLogRow(Base):
    __tablename__ = "audit_logs"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    event_type: Mapped[str] = mapped_column(String(64), nullable=False)
    actor_id: Mapped[str | None] = mapped_column(String(255))  # nullable -- e.g. pre-authentication denial
    actor_type: Mapped[str | None] = mapped_column(String(32))  # ADMIN / MEMBER / SYSTEM / VENDOR_WEBHOOK
    action: Mapped[str | None] = mapped_column(String(128))
    target_entity: Mapped[str | None] = mapped_column(String(128))
    target_id: Mapped[str | None] = mapped_column(String(255))
    result: Mapped[str | None] = mapped_column(String(32))  # ALLOW / DENY / SUCCESS / FAILURE
    payload: Mapped[Dict[str, Any]] = mapped_column(JSONB, nullable=False, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    # Append-only, same policy as ledger_entries/kyc_state_transitions: no
    # updated_at column, no application-level UPDATE/DELETE grant.


class SQLAlchemyAuditLogWriter(AuditLogWriter):
    """
    Implements kyc.core.AuditLogWriter (write(event_type, payload)).
    Extracts actor/action/target/result into dedicated indexed columns
    when present in the payload (for queryability), while keeping the
    full original payload in the JSONB column (nothing is lost/summarized
    away).
    """

    def __init__(self, db: Session):
        self.db = db

    def write(self, event_type: str, payload: Dict[str, Any]) -> None:
        row = AuditLogRow(
            id=uuid.uuid4(),
            event_type=event_type,
            actor_id=self._stringify(payload.get("actor_id")),
            actor_type=payload.get("actor_type"),
            action=payload.get("action"),
            target_entity=payload.get("target_entity") or payload.get("resource"),
            target_id=self._stringify(payload.get("target_id") or payload.get("verification_id")
                                       or payload.get("member_id")),
            result=payload.get("result"),
            payload=payload,
        )
        self.db.add(row)
        self.db.flush()

    @staticmethod
    def _stringify(value: Optional[Any]) -> Optional[str]:
        return str(value) if value is not None else None
