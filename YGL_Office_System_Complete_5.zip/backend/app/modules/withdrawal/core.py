"""
Withdrawal core domain logic -- gates Commission Withdrawal (distinct
from Commission Earn, which the frozen Commission Engine handles entirely
unchanged; this module NEVER recalculates or duplicates any commission
math, it only decides whether a withdrawal REQUEST may proceed).

Per Business Decision: Withdrawal requires a separately-completed
"Withdrawal KYC" (Identity + NID/BR + Face + Liveness + Payment-account +
Fraud screening). WHICH module/flow produces that approval is an open
architecture question (flagged separately, not decided here) -- this
module only models the GATE itself: a WithdrawalKYCStatus record per
member, and a WithdrawalService that checks it plus available ledger
balance before allowing a withdrawal request to be created.

Balance lookup is via an injected callable, never a direct
commission_engine import -- only app/services/commission_service/ may
import commission_engine (architecture boundary, unchanged).
"""
from __future__ import annotations

import uuid
from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import datetime, timezone
from decimal import Decimal
from typing import Callable, Dict, Optional


class WithdrawalKYCStatusValue:
    NOT_STARTED = "NOT_STARTED"
    APPROVED = "APPROVED"

    VALID = {NOT_STARTED, APPROVED}


@dataclass
class WithdrawalKYCStatus:
    member_id: str
    status: str
    approved_at: Optional[datetime] = None


@dataclass
class WithdrawalRequest:
    id: str
    member_id: str
    amount: Decimal
    status: str  # PENDING (created here; actual money-movement is out of this module's scope)
    created_at: datetime


class WithdrawalKYCRequiredError(Exception):
    """Raised when a withdrawal is attempted without an APPROVED
    Withdrawal KYC status -- per the Business Decision, a non-zero ledger
    balance does NOT override this requirement."""


class InsufficientBalanceError(Exception):
    def __init__(self, available: Decimal, requested: Decimal):
        self.available = available
        self.requested = requested
        super().__init__(f"Requested {requested} exceeds available balance {available}.")


class InvalidWithdrawalAmountError(Exception):
    pass


class WithdrawalKYCStatusRepository(ABC):
    @abstractmethod
    def get_for_member(self, member_id: str) -> WithdrawalKYCStatus:
        """Must return a NOT_STARTED status object (never None/missing)
        for a member with no record yet -- callers should not need to
        special-case 'no row exists'."""
        raise NotImplementedError

    @abstractmethod
    def save(self, status: WithdrawalKYCStatus) -> None:
        raise NotImplementedError


class WithdrawalRequestRepository(ABC):
    @abstractmethod
    def save(self, request: WithdrawalRequest) -> None:
        raise NotImplementedError

    @abstractmethod
    def list_for_member(self, member_id: str) -> list:
        raise NotImplementedError


class InMemoryWithdrawalKYCStatusRepository(WithdrawalKYCStatusRepository):
    def __init__(self):
        self._by_member: Dict[str, WithdrawalKYCStatus] = {}

    def get_for_member(self, member_id: str) -> WithdrawalKYCStatus:
        return self._by_member.get(member_id) or WithdrawalKYCStatus(
            member_id=member_id, status=WithdrawalKYCStatusValue.NOT_STARTED,
        )

    def save(self, status: WithdrawalKYCStatus) -> None:
        self._by_member[status.member_id] = status


class InMemoryWithdrawalRequestRepository(WithdrawalRequestRepository):
    def __init__(self):
        self._records = []

    def save(self, request: WithdrawalRequest) -> None:
        self._records.append(request)

    def list_for_member(self, member_id: str) -> list:
        return [r for r in self._records if r.member_id == member_id]
