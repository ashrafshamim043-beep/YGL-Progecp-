"""
Account KYC (Initial/lightweight tier) -- Mobile verification + (NID or
Birth Registration) data capture, per Business Decision (Y.G.L Phase 8,
"Member KYC, 3-Account Policy and Commission Withdrawal") -- CONFIRMED
by follow-up Business Decision message.

Scope boundary (CONFIRMED): this tier does NOT perform automated
government-database verification or face/liveness matching -- that
remains the EXISTING kyc/ module's job (CONFIRMED as "Withdrawal KYC"),
which already performs exactly that via Sumsub. This module only captures
mobile-OTP-verification status + document data/image reference, and
enforces the 3-Account Policy via kyc_identity/core.py before activating
the member.

Status vocabulary (CONFIRMED, deliberately NOT "APPROVED"/"VERIFIED" in a
generic sense): "VERIFIED" here means Y.G.L's own defined initial-
verification workflow completed -- it must NEVER be read or presented as
"government database verified". Government/NID/Birth-Registration
automated verification is an explicitly future, not-yet-decided
enhancement (CONFIRMED: "Business Decision ছাড়া এখন implement করবে না").

Pure Python, zero external dependencies -- same pattern as every other
module here.
"""
from __future__ import annotations

import uuid
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Dict, List, Optional

from app.modules.kyc_identity.core import (
    KYCIdentityRepository, DocumentType, link_member_to_identity,
    MaxMemberIdsExceededError, InvalidDocumentTypeError,
)


# ---------------------------------------------------------------------------
# Status vocabulary (CONFIRMED terminology -- never rename to imply
# government verification)
# ---------------------------------------------------------------------------

class AccountKYCStatus:
    INITIAL_KYC_SUBMITTED = "INITIAL_KYC_SUBMITTED"
    INITIAL_KYC_VERIFIED = "INITIAL_KYC_VERIFIED"
    REJECTED = "REJECTED"


# ---------------------------------------------------------------------------
# Domain records
# ---------------------------------------------------------------------------

@dataclass
class AccountKYCRecord:
    id: str
    member_id: str
    kyc_identity_id: str
    document_type: str
    document_image_reference: str  # storage pointer, never the raw image bytes here
    mobile_number: str
    mobile_otp_verified: bool
    status: str  # AccountKYCStatus.*
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------

class MobileNotVerifiedError(Exception):
    """Raised when account KYC is submitted before mobile OTP verification
    completes. Per Business Decision, mobile verification is mandatory
    for the initial tier regardless of document type."""


# ---------------------------------------------------------------------------
# Repository interface + in-memory implementation
# ---------------------------------------------------------------------------

class AccountKYCRepository(ABC):
    @abstractmethod
    def save(self, record: AccountKYCRecord) -> None:
        raise NotImplementedError

    @abstractmethod
    def get_for_member(self, member_id: str) -> Optional[AccountKYCRecord]:
        raise NotImplementedError


class InMemoryAccountKYCRepository(AccountKYCRepository):
    def __init__(self):
        self._by_member: Dict[str, AccountKYCRecord] = {}

    def save(self, record: AccountKYCRecord) -> None:
        self._by_member[record.member_id] = record

    def get_for_member(self, member_id: str) -> Optional[AccountKYCRecord]:
        return self._by_member.get(member_id)


# ---------------------------------------------------------------------------
# Member-activation port (mirrors kyc/core.py's MemberActivationPort
# pattern -- this module never touches Member's internals directly)
# ---------------------------------------------------------------------------

class MemberActivationPort(ABC):
    @abstractmethod
    def activate_member(self, member_id: str) -> bool:
        raise NotImplementedError
