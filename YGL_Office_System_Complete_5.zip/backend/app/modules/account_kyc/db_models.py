"""
AccountKYC persistence model. Status column stores the CONFIRMED Y.G.L-
defined terminology (INITIAL_KYC_SUBMITTED / INITIAL_KYC_VERIFIED /
REJECTED) -- never a value implying government-database verification.
"""
import uuid
from datetime import datetime

from sqlalchemy import String, DateTime, ForeignKey, Boolean, Text, func
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.db.session import Base


class AccountKYCRow(Base):
    __tablename__ = "account_kyc_records"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    member_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("members.id"), nullable=False)
    kyc_identity_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("kyc_identities.id"), nullable=False)
    document_type: Mapped[str] = mapped_column(String(32), nullable=False)
    document_image_reference: Mapped[str] = mapped_column(Text, nullable=False)
    mobile_number: Mapped[str] = mapped_column(String(32), nullable=False)
    mobile_otp_verified: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    status: Mapped[str] = mapped_column(String(32), nullable=False, default="INITIAL_KYC_SUBMITTED")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
