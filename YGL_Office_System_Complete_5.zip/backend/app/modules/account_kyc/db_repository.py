"""
SQLAlchemy-backed AccountKYCRepository + MemberActivationPort adapter.
Implements the SAME interfaces (account_kyc/core.py) that the in-memory
test doubles already implement and that this module's 6 tests already
prove correct -- no new business logic here, only persistence.
"""
import uuid
from datetime import datetime, timezone
from typing import Optional

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.modules.account_kyc.core import AccountKYCRecord, AccountKYCRepository, MemberActivationPort
from app.modules.account_kyc.db_models import AccountKYCRow
from app.modules.member.db_models import Member, MemberStatusHistory
from app.modules.member.core import MemberAccountStatus
from app.modules.audit.db_repository import AuditLogRow


class SQLAlchemyAccountKYCRepository(AccountKYCRepository):
    def __init__(self, db: Session):
        self.db = db

    def save(self, record: AccountKYCRecord) -> None:
        row = self.db.get(AccountKYCRow, uuid.UUID(record.id))
        if row is None:
            row = AccountKYCRow(
                id=uuid.UUID(record.id), member_id=uuid.UUID(record.member_id),
                kyc_identity_id=uuid.UUID(record.kyc_identity_id), document_type=record.document_type,
                document_image_reference=record.document_image_reference, mobile_number=record.mobile_number,
                mobile_otp_verified=record.mobile_otp_verified, status=record.status,
            )
            self.db.add(row)
        else:
            row.status = record.status
        self.db.flush()

    def get_for_member(self, member_id: str) -> Optional[AccountKYCRecord]:
        stmt = select(AccountKYCRow).where(AccountKYCRow.member_id == uuid.UUID(member_id))
        row = self.db.execute(stmt).scalar_one_or_none()
        if row is None:
            return None
        return AccountKYCRecord(
            id=str(row.id), member_id=str(row.member_id), kyc_identity_id=str(row.kyc_identity_id),
            document_type=row.document_type, document_image_reference=row.document_image_reference,
            mobile_number=row.mobile_number, mobile_otp_verified=row.mobile_otp_verified,
            status=row.status, created_at=row.created_at,
        )


class SQLAlchemyAccountKYCMemberActivationPort(MemberActivationPort):
    """
    Transactional activation for the Initial/lightweight KYC tier --
    mirrors kyc/member_activation_adapter.py's all-or-nothing pattern
    (status + history + audit, one transaction, rollback on any failure)
    but is a SEPARATE class because it activates from PENDING via the
    Initial-KYC path specifically, not the Withdrawal-KYC path.
    """
    def __init__(self, db: Session):
        self.db = db

    def activate_member(self, member_id: str) -> bool:
        try:
            member = self.db.get(Member, uuid.UUID(member_id))
            if member is None or member.account_status != MemberAccountStatus.PENDING:
                return False

            now = datetime.now(timezone.utc)
            member.account_status = MemberAccountStatus.ACTIVE

            self.db.add(MemberStatusHistory(
                id=uuid.uuid4(), member_id=member.id, account_status=MemberAccountStatus.ACTIVE,
                effective_from=now, effective_to=None, changed_by=None,
            ))
            self.db.add(AuditLogRow(
                id=uuid.uuid4(), event_type="MEMBER_ACTIVATED_VIA_INITIAL_KYC",
                actor_id="ACCOUNT_KYC_SERVICE", actor_type="SYSTEM",
                action="ACTIVATE_MEMBER", target_entity="member", target_id=member_id,
                result="SUCCESS", payload={"member_id": member_id, "tier": "INITIAL_KYC"},
            ))
            self.db.flush()
            self.db.commit()
            return True
        except Exception:
            self.db.rollback()
            return False
