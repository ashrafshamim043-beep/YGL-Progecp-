"""
Identity KYC core domain logic -- Account KYC (lightweight: mobile +
NID-or-Birth-Registration) and the Master KYC Identity <-> Member ID
linking rule (max 3 Member IDs per real-world identity).

Per Business Decision (Y.G.L Phase 8, "Member KYC, 3-Account Policy and
Commission Withdrawal"): this is DELIBERATELY separate from the existing
app/modules/kyc/ module (Sumsub-based, full identity+face+liveness --
that module maps to "Withdrawal KYC" per the new decision, NOT to account
activation). This module's completion is what activates a Member
(PENDING -> ACTIVE), not the other module's.

Pure Python, zero external dependencies -- same pattern as every other
core.py in this system.
"""
from __future__ import annotations

import uuid
from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Dict, List, Optional


MAX_MEMBER_IDS_PER_IDENTITY = 3  # Business Decision #3, explicit and fixed


class DocumentType:
    NID = "NID"
    BIRTH_REGISTRATION = "BIRTH_REGISTRATION"

    VALID = {NID, BIRTH_REGISTRATION}


# ---------------------------------------------------------------------------
# Domain records
# ---------------------------------------------------------------------------

@dataclass
class MasterKYCIdentity:
    """One real-world person. Identified by (document_type, document_number)
    -- per the Business Decision, this pairing is what determines whether
    two Member registrations belong to 'the same person'."""
    id: str
    document_type: str
    document_number: str
    created_at: datetime


@dataclass
class MemberIdentityLink:
    """One Member ID's link to a MasterKYCIdentity. At most
    MAX_MEMBER_IDS_PER_IDENTITY of these may exist for a single
    master_identity_id -- enforced by IdentityKYCService, never bypassable
    through this repository layer alone (the repository only stores; the
    service enforces the cap before ever calling save())."""
    id: str
    member_id: str
    master_identity_id: str
    created_at: datetime


@dataclass
class AccountKYCRecord:
    """One member's completed Account KYC (mobile + NID-or-BR). Distinct
    from Withdrawal KYC (a different module's concern per the Business
    Decision) -- completing THIS record is what makes a Member ACTIVE."""
    id: str
    member_id: str
    master_identity_id: str
    mobile_number: str
    document_type: str
    document_number: str
    created_at: datetime


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------

class MobileNotVerifiedError(Exception):
    """Raised when Account KYC is attempted without a verified mobile
    number -- per the Business Decision, mobile verification is mandatory
    regardless of which document type is used."""


class InvalidDocumentTypeError(Exception):
    pass


class DuplicateAccountKYCError(Exception):
    """Raised when a member who has already completed Account KYC
    attempts it again -- Account KYC is a one-time event per Member ID."""


class MaxMemberIdentityLimitError(Exception):
    """Raised when a 4th Member ID attempts to link to the SAME
    MasterKYCIdentity (same document_type + document_number) -- Business
    Decision #3's hard cap, enforced unconditionally."""
    def __init__(self, master_identity_id: str):
        self.master_identity_id = master_identity_id
        super().__init__(
            f"MasterKYCIdentity '{master_identity_id}' already has "
            f"{MAX_MEMBER_IDS_PER_IDENTITY} linked Member IDs -- the maximum allowed."
        )


# ---------------------------------------------------------------------------
# Repository interfaces
# ---------------------------------------------------------------------------

class MasterKYCIdentityRepository(ABC):
    @abstractmethod
    def get_by_document(self, document_type: str, document_number: str) -> Optional[MasterKYCIdentity]:
        raise NotImplementedError

    @abstractmethod
    def save(self, identity: MasterKYCIdentity) -> None:
        raise NotImplementedError


class MemberIdentityLinkRepository(ABC):
    @abstractmethod
    def save(self, link: MemberIdentityLink) -> None:
        raise NotImplementedError

    @abstractmethod
    def list_for_identity(self, master_identity_id: str) -> List[MemberIdentityLink]:
        raise NotImplementedError

    @abstractmethod
    def get_for_member(self, member_id: str) -> Optional[MemberIdentityLink]:
        raise NotImplementedError


class AccountKYCRepository(ABC):
    @abstractmethod
    def save(self, record: AccountKYCRecord) -> None:
        raise NotImplementedError

    @abstractmethod
    def get_for_member(self, member_id: str) -> Optional[AccountKYCRecord]:
        raise NotImplementedError


# ---------------------------------------------------------------------------
# In-memory implementations (testing)
# ---------------------------------------------------------------------------

class InMemoryMasterKYCIdentityRepository(MasterKYCIdentityRepository):
    def __init__(self):
        self._by_id: Dict[str, MasterKYCIdentity] = {}

    def get_by_document(self, document_type: str, document_number: str) -> Optional[MasterKYCIdentity]:
        for identity in self._by_id.values():
            if identity.document_type == document_type and identity.document_number == document_number:
                return identity
        return None

    def save(self, identity: MasterKYCIdentity) -> None:
        self._by_id[identity.id] = identity


class InMemoryMemberIdentityLinkRepository(MemberIdentityLinkRepository):
    def __init__(self):
        self._records: List[MemberIdentityLink] = []

    def save(self, link: MemberIdentityLink) -> None:
        self._records.append(link)

    def list_for_identity(self, master_identity_id: str) -> List[MemberIdentityLink]:
        return [r for r in self._records if r.master_identity_id == master_identity_id]

    def get_for_member(self, member_id: str) -> Optional[MemberIdentityLink]:
        for r in self._records:
            if r.member_id == member_id:
                return r
        return None


class InMemoryAccountKYCRepository(AccountKYCRepository):
    def __init__(self):
        self._by_member_id: Dict[str, AccountKYCRecord] = {}

    def save(self, record: AccountKYCRecord) -> None:
        self._by_member_id[record.member_id] = record

    def get_for_member(self, member_id: str) -> Optional[AccountKYCRecord]:
        return self._by_member_id.get(member_id)
