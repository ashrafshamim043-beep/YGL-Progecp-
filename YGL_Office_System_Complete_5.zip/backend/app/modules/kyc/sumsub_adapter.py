"""
SumsubAdapter -- the ONLY place in this codebase that knows Sumsub's actual
webhook field names, HMAC scheme, or GREEN/RED vocabulary.

Per Business Owner directive: no production Sumsub credentials or live
applicant calls are permitted yet (Production Vendor Approval is PENDING --
see YGL_Sumsub_Due_Diligence_Architecture_Gate.md Sections A/B open items).
Accordingly:
  - verify_webhook_signature() and parse_webhook_event() are REAL,
    fully-working, offline logic (HMAC computation and payload parsing need
    no network access and no credentials -- they are pure functions over
    bytes you already have).
  - create_applicant() and get_verification_url() DELIBERATELY raise
    ProductionCredentialsNotConfiguredError -- they would require a live
    HTTP call to Sumsub's API with a real API token, which this phase does
    not have and must not use.
"""
from __future__ import annotations

import hashlib
import hmac
import json
from datetime import datetime, timezone
from typing import Optional

from app.modules.kyc.core import (
    KYCProviderInterface,
    NormalizedKYCEvent,
    NormalizedDecision,
    UnknownEventTypeError,
    compute_idempotency_key,
)

PROVIDER_NAME = "SUMSUB"

# Whitelist of Sumsub webhook `type` values this adapter understands.
# Anything else is explicitly rejected (Business Owner correction: unknown
# events are never silently ignored).
_RECOGNIZED_EVENT_TYPES = {"applicantReviewed"}


class ProductionCredentialsNotConfiguredError(Exception):
    """Raised by any SumsubAdapter method that would require a live API call.
    This is intentional in the current phase -- see this module's docstring."""


class SumsubAdapter(KYCProviderInterface):
    def __init__(self, webhook_secret: str, signature_algorithm: str = "sha256"):
        """
        webhook_secret: the HMAC secret configured in Sumsub's Webhook
        Manager dashboard (per Sumsub's own documentation). This is NOT a
        production API token -- it only lets us verify webhook authenticity,
        it does not let us call Sumsub's API. Even with only this secret
        configured (no API token), signature verification and payload
        parsing are fully functional and safe to use/test.
        """
        if not webhook_secret:
            raise ValueError("webhook_secret must be provided.")
        self._secret = webhook_secret.encode("utf-8")
        self._algo = signature_algorithm.lower()
        if self._algo not in ("sha256", "sha512"):
            raise ValueError(f"Unsupported signature algorithm: {signature_algorithm}")

    def verify_webhook_signature(self, raw_payload: bytes, signature_header: str) -> bool:
        """Recomputes the HMAC digest over the RAW (unparsed) payload bytes
        and compares it to the provided signature, using constant-time
        comparison to avoid timing side-channels."""
        digestmod = hashlib.sha256 if self._algo == "sha256" else hashlib.sha512
        expected = hmac.new(self._secret, raw_payload, digestmod).hexdigest()
        return hmac.compare_digest(expected, (signature_header or "").strip().lower())

    def parse_webhook_event(self, raw_payload: bytes) -> NormalizedKYCEvent:
        try:
            data = json.loads(raw_payload)
        except (json.JSONDecodeError, UnicodeDecodeError) as e:
            raise UnknownEventTypeError(f"Payload is not valid JSON: {e}")

        event_type = data.get("type")
        if event_type not in _RECOGNIZED_EVENT_TYPES:
            raise UnknownEventTypeError(f"Unrecognized Sumsub webhook type: {event_type!r}")

        applicant_id = data.get("applicantId")
        if not applicant_id:
            raise UnknownEventTypeError("Webhook payload missing applicantId.")

        review_result = data.get("reviewResult", {}) or {}
        review_answer = review_result.get("reviewAnswer")
        reject_type = review_result.get("reviewRejectType")  # e.g. "FINAL" / "RETRY"

        decision = self._map_decision(review_answer, reject_type, data.get("reviewStatus"))

        created_at_ms = data.get("createdAtMs")
        event_timestamp = self._parse_timestamp(created_at_ms)

        idempotency_key = compute_idempotency_key(
            provider_name=PROVIDER_NAME,
            provider_applicant_id=applicant_id,
            event_type=event_type,
            event_timestamp_ms=str(created_at_ms),
        )

        return NormalizedKYCEvent(
            provider_name=PROVIDER_NAME,
            provider_applicant_id=applicant_id,
            decision=decision,
            event_timestamp=event_timestamp,
            idempotency_key=idempotency_key,
            # Sumsub's payload has no single canonical "event ID" distinct
            # from (applicantId, type, createdAtMs) -- per the Due-Diligence
            # doc's finding. correlationId is the closest analog Sumsub
            # supplies; we record it here, separately from idempotency_key,
            # exactly as directed (never conflate the two).
            provider_native_event_id=data.get("correlationId"),
            raw_payload_reference=hashlib.sha256(raw_payload).hexdigest(),
            metadata={
                "reviewStatus": data.get("reviewStatus"),
                "levelName": data.get("levelName"),
                "moderationComment": review_result.get("moderationComment"),
                "rejectLabels": review_result.get("rejectLabels"),
            },
        )

    @staticmethod
    def _map_decision(review_answer: Optional[str], reject_type: Optional[str],
                       review_status: Optional[str]) -> NormalizedDecision:
        if review_status is not None and review_status != "completed":
            return NormalizedDecision.IN_PROGRESS
        if review_answer == "GREEN":
            return NormalizedDecision.APPROVED
        if review_answer == "RED":
            if reject_type == "FINAL":
                return NormalizedDecision.REJECTED
            return NormalizedDecision.MANUAL_REVIEW_REQUIRED
        # Unrecognized/absent reviewAnswer with a completed status is treated
        # conservatively as requiring human judgement, never auto-approved.
        return NormalizedDecision.MANUAL_REVIEW_REQUIRED

    @staticmethod
    def _parse_timestamp(created_at_ms) -> datetime:
        if created_at_ms is None:
            return datetime.now(timezone.utc)
        try:
            # Sumsub's documented format: "2020-02-21 13:23:19.321"
            return datetime.strptime(str(created_at_ms), "%Y-%m-%d %H:%M:%S.%f").replace(tzinfo=timezone.utc)
        except ValueError:
            return datetime.now(timezone.utc)

    def create_applicant(self, member_id: str) -> str:
        raise ProductionCredentialsNotConfiguredError(
            "create_applicant() requires a live Sumsub API call with a production "
            "API token. Production Vendor Approval is still PENDING (see "
            "YGL_Sumsub_Due_Diligence_Architecture_Gate.md) -- this method must not "
            "be called until procurement/legal confirmation is complete."
        )

    def get_verification_url(self, provider_applicant_id: str) -> str:
        raise ProductionCredentialsNotConfiguredError(
            "get_verification_url() requires a live Sumsub API call with a production "
            "API token. Production Vendor Approval is still PENDING -- this method "
            "must not be called until procurement/legal confirmation is complete."
        )
