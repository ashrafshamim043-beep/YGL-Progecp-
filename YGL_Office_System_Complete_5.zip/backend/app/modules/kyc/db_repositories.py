"""
KYC persistence models (SQLAlchemy). These implement the SAME repository
interfaces defined in app/modules/kyc/core.py (KYCVerificationRepository,
KYCStateTransitionRepository) that the in-memory test doubles implement --
this file is the production-swap-in, not a parallel design.

Honesty note: this file has been syntax-checked (py_compile) but NOT run
against a live PostgreSQL database in this environment -- there is no
network access here to install SQLAlchemy/psycopg or run Postgres. It must
be verified against a real database by the team before being relied upon
in staging/production. This is the same disclosure that applies to the
Phase 8.1 Foundation models delivered earlier.
"""
import uuid
from datetime import datetime
from typing import Optional, List

from sqlalchemy import String, DateTime, ForeignKey, Text, Boolean, UniqueConstraint, func, select
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, Session

from app.db.session import Base
from app.modules.kyc.core import (
    KYCVerificationRepository, KYCStateTransitionRepository,
    KYCVerification, KYCStateTransitionRecord, KYCState,
)


class KYCVerificationRow(Base):
    __tablename__ = "kyc_verifications"
    __table_args__ = (
        # Enforces "unique constraint on provider + provider_applicant_id"
        # per Business Owner directive -- the same (provider, applicant_id)
        # pair can never map to two different verification rows.
        UniqueConstraint("provider_name", "provider_applicant_id",
                          name="uq_kyc_verifications_provider_applicant"),
    )

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    member_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("members.id"), nullable=False)
    provider_name: Mapped[str] = mapped_column(String(32), nullable=False)
    provider_applicant_id: Mapped[str] = mapped_column(String(255), nullable=False)
    state: Mapped[str] = mapped_column(String(32), nullable=False, default=KYCState.PENDING.value)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    # NOTE: updated_at uses onupdate deliberately -- this row's CURRENT
    # STATE is allowed to change (it's a pointer to "where is this
    # verification right now"), unlike kyc_state_transitions below, which
    # is append-only. The full history lives in kyc_state_transitions;
    # this row is a queryable "current state" cache, not the source of truth.


class KYCStateTransitionRow(Base):
    __tablename__ = "kyc_state_transitions"
    # No __table_args__ unique constraint on a business key here on purpose --
    # each row is a distinct historical fact. Idempotency is enforced via
    # idempotency_key below, with its own constraint.

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    kyc_verification_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("kyc_verifications.id"), nullable=False
    )
    from_state: Mapped[str | None] = mapped_column(String(32))
    to_state: Mapped[str] = mapped_column(String(32), nullable=False)
    valid_previous_state_check: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    actor_type: Mapped[str] = mapped_column(String(32), nullable=False)  # MEMBER / VENDOR_WEBHOOK / ADMIN
    actor_id: Mapped[str] = mapped_column(String(255), nullable=False)
    provider_applicant_id: Mapped[str | None] = mapped_column(String(255))
    # Per Business Owner correction #2: named idempotency_key, never
    # vendor_event_id. provider_native_event_id (e.g. Sumsub's
    # correlationId) is a SEPARATE, optional column.
    idempotency_key: Mapped[str | None] = mapped_column(String(128), unique=True)
    provider_native_event_id: Mapped[str | None] = mapped_column(String(255))
    timestamp: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    # Insertion-order sequence, used by the chain-gaplessness check instead
    # of `timestamp` (see core.py's _chain_is_gapless docstring for why).
    sequence: Mapped[int] = mapped_column(autoincrement=True, primary_key=False, nullable=False, unique=True)

    # Append-only: no columns here are ever UPDATEd after insert. DB-level
    # UPDATE/DELETE grants for the application role must be revoked on this
    # table (see Architecture Blueprint v4 Section K, same pattern as
    # ledger_entries).


class SQLAlchemyKYCVerificationRepository(KYCVerificationRepository):
    """Production adapter. Constructed with a SQLAlchemy Session per request
    (see app/db/session.py's get_db() dependency) -- not a long-lived
    singleton, matching how Commission Engine's own dependencies are
    constructed fresh in the service layer, never held as global state."""

    def __init__(self, db: Session):
        self.db = db

    def _row_to_domain(self, row: Optional[KYCVerificationRow]) -> Optional[KYCVerification]:
        if row is None:
            return None
        return KYCVerification(
            id=str(row.id), member_id=str(row.member_id),
            provider_name=row.provider_name, provider_applicant_id=row.provider_applicant_id,
            state=KYCState(row.state), created_at=row.created_at, updated_at=row.updated_at,
        )

    def get_by_id(self, verification_id: str) -> Optional[KYCVerification]:
        row = self.db.get(KYCVerificationRow, uuid.UUID(verification_id))
        return self._row_to_domain(row)

    def get_by_provider_applicant_id(self, provider_name: str, provider_applicant_id: str) -> Optional[KYCVerification]:
        stmt = select(KYCVerificationRow).where(
            KYCVerificationRow.provider_name == provider_name,
            KYCVerificationRow.provider_applicant_id == provider_applicant_id,
        )
        row = self.db.execute(stmt).scalar_one_or_none()
        return self._row_to_domain(row)

    def get_active_for_member(self, member_id: str) -> Optional[KYCVerification]:
        stmt = (
            select(KYCVerificationRow)
            .where(KYCVerificationRow.member_id == uuid.UUID(member_id))
            .order_by(KYCVerificationRow.created_at.desc())
        )
        rows = self.db.execute(stmt).scalars().all()
        if not rows:
            return None
        non_terminal = [r for r in rows if r.state not in (KYCState.APPROVED.value, KYCState.REJECTED.value)]
        return self._row_to_domain(non_terminal[0] if non_terminal else rows[0])

    def save(self, verification: KYCVerification) -> None:
        row = self.db.get(KYCVerificationRow, uuid.UUID(verification.id))
        if row is None:
            row = KYCVerificationRow(
                id=uuid.UUID(verification.id), member_id=uuid.UUID(verification.member_id),
                provider_name=verification.provider_name,
                provider_applicant_id=verification.provider_applicant_id,
                state=verification.state.value,
            )
            self.db.add(row)
        else:
            row.state = verification.state.value
        self.db.flush()


class SQLAlchemyKYCStateTransitionRepository(KYCStateTransitionRepository):
    def __init__(self, db: Session):
        self.db = db

    def append(self, transition: KYCStateTransitionRecord) -> None:
        row = KYCStateTransitionRow(
            id=uuid.UUID(transition.id),
            kyc_verification_id=uuid.UUID(transition.kyc_verification_id),
            from_state=transition.from_state.value if transition.from_state else None,
            to_state=transition.to_state.value,
            actor_type=transition.actor_type, actor_id=transition.actor_id,
            provider_applicant_id=transition.provider_applicant_id,
            idempotency_key=transition.idempotency_key,
            timestamp=transition.timestamp,
        )
        self.db.add(row)
        self.db.flush()

    def list_for_verification(self, verification_id: str) -> List[KYCStateTransitionRecord]:
        stmt = (
            select(KYCStateTransitionRow)
            .where(KYCStateTransitionRow.kyc_verification_id == uuid.UUID(verification_id))
            .order_by(KYCStateTransitionRow.sequence.asc())  # insertion order, NOT timestamp -- see core.py
        )
        rows = self.db.execute(stmt).scalars().all()
        return [
            KYCStateTransitionRecord(
                id=str(r.id), kyc_verification_id=str(r.kyc_verification_id),
                from_state=KYCState(r.from_state) if r.from_state else None,
                to_state=KYCState(r.to_state), actor_type=r.actor_type, actor_id=r.actor_id,
                provider_applicant_id=r.provider_applicant_id, idempotency_key=r.idempotency_key,
                timestamp=r.timestamp,
            )
            for r in rows
        ]

    def has_idempotency_key(self, idempotency_key: str) -> bool:
        stmt = select(KYCStateTransitionRow.id).where(KYCStateTransitionRow.idempotency_key == idempotency_key)
        return self.db.execute(stmt).first() is not None
