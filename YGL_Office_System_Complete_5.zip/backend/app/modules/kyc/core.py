"""
KYC core domain logic.

Deliberately pure Python (no FastAPI/SQLAlchemy import here) so this module
is testable in any environment, and so persistence is fully swappable
(mirrors commission_engine's own pattern: abstract provider interfaces +
InMemory implementations for tests, DB-backed adapters for production --
see app/modules/kyc/db_repositories.py for the SQLAlchemy-backed versions).

Per Business Owner correction: the state machine is Y.G.L's own,
provider-agnostic business states. Vendor (Sumsub) internal workflow
details are normalized into these states by the adapter -- they are never
hard-coded into this module.
"""
from __future__ import annotations

import hashlib
import hmac
import uuid
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Optional, List, Dict, Any


# ---------------------------------------------------------------------------
# Y.G.L business states (provider-agnostic, per Business Owner correction)
# ---------------------------------------------------------------------------

class KYCState(str, Enum):
    PENDING = "PENDING"
    DOCUMENT_SUBMITTED = "DOCUMENT_SUBMITTED"
    VERIFICATION_IN_PROGRESS = "VERIFICATION_IN_PROGRESS"
    MANUAL_REVIEW = "MANUAL_REVIEW"
    APPROVED = "APPROVED"
    REJECTED = "REJECTED"


# Allowed transitions. Each key's value-set is the states it may move to.
# This is the single source of truth for "valid previous state" checks.
_ALLOWED_TRANSITIONS: Dict[KYCState, set] = {
    KYCState.PENDING: {KYCState.DOCUMENT_SUBMITTED},
    KYCState.DOCUMENT_SUBMITTED: {KYCState.VERIFICATION_IN_PROGRESS},
    KYCState.VERIFICATION_IN_PROGRESS: {
        KYCState.APPROVED, KYCState.REJECTED, KYCState.MANUAL_REVIEW,
        # A provider may also send an updated in-progress event (e.g. a
        # second, more detailed "in progress" webhook) -- staying in the
        # same state is not a transition violation.
        KYCState.VERIFICATION_IN_PROGRESS,
    },
    KYCState.MANUAL_REVIEW: {KYCState.APPROVED, KYCState.REJECTED},
    # Terminal states can still receive a LATER, legitimate re-decision
    # (Sumsub's own documented behavior: an approved applicant can later be
    # flagged as fraudulent). This is a deliberate, explicit exception, not
    # an open-ended "anything goes" rule -- only APPROVED -> REJECTED is
    # permitted post-terminal (a fraud-reversal), never the other direction,
    # and it always requires a fresh, separately-idempotency-checked event.
    KYCState.APPROVED: {KYCState.REJECTED},
    KYCState.REJECTED: set(),
}


class InvalidStateTransitionError(Exception):
    """Raised when a proposed KYCState transition is not in _ALLOWED_TRANSITIONS."""


def validate_transition(from_state: Optional[KYCState], to_state: KYCState) -> None:
    """Raises InvalidStateTransitionError if this transition is not allowed.
    from_state=None is only valid when to_state=PENDING (initial creation)."""
    if from_state is None:
        if to_state != KYCState.PENDING:
            raise InvalidStateTransitionError(
                f"A KYC verification must start at PENDING, not {to_state}."
            )
        return
    allowed = _ALLOWED_TRANSITIONS.get(from_state, set())
    if to_state not in allowed:
        raise InvalidStateTransitionError(
            f"Transition {from_state} -> {to_state} is not allowed. "
            f"Allowed from {from_state}: {sorted(s.value for s in allowed) or '(none, terminal)'}"
        )


# ---------------------------------------------------------------------------
# Provider-agnostic normalized event
# ---------------------------------------------------------------------------

class NormalizedDecision(str, Enum):
    """Provider-agnostic decision, independent of any vendor's own vocabulary
    (e.g. Sumsub's GREEN/RED reviewAnswer is mapped to this, never used
    directly outside the adapter)."""
    IN_PROGRESS = "IN_PROGRESS"
    APPROVED = "APPROVED"
    REJECTED = "REJECTED"
    MANUAL_REVIEW_REQUIRED = "MANUAL_REVIEW_REQUIRED"


@dataclass(frozen=True)
class NormalizedKYCEvent:
    """Provider-agnostic representation of a single KYC provider event.
    This is the ONLY shape the KYC state machine and YGLKYCService ever see
    -- no Sumsub-specific field name crosses this boundary."""
    provider_name: str  # e.g. "SUMSUB" -- an identifier, not a behavior switch
    provider_applicant_id: str
    decision: NormalizedDecision
    event_timestamp: datetime
    idempotency_key: str  # Y.G.L-computed key (see compute_idempotency_key below);
                           # NEVER called "vendor_event_id" per Business Owner correction
    provider_native_event_id: Optional[str] = None  # populated only if the
                                                      # provider actually supplies
                                                      # a real event ID; kept
                                                      # separate from idempotency_key
    raw_payload_reference: Optional[str] = None  # e.g. a hash/pointer, never the
                                                   # raw biometric payload itself
    metadata: Dict[str, Any] = field(default_factory=dict)  # normalized, non-biometric
                                                               # extra info (e.g. reject reason)


def compute_idempotency_key(provider_name: str, provider_applicant_id: str,
                             event_type: str, event_timestamp_ms: str) -> str:
    """Deterministic idempotency key. Two webhook deliveries with identical
    (provider, applicant, event_type, timestamp) produce the identical key --
    this is what makes duplicate-delivery detection possible without relying
    on the provider supplying its own event ID."""
    raw = f"{provider_name}::{provider_applicant_id}::{event_type}::{event_timestamp_ms}"
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


# ---------------------------------------------------------------------------
# Provider interface (vendor abstraction boundary)
# ---------------------------------------------------------------------------

class KYCProviderInterface(ABC):
    """Every KYC vendor adapter (Sumsub today, any future vendor) implements
    this exact contract. YGLKYCService never imports a vendor-specific class
    directly -- only this interface."""

    @abstractmethod
    def verify_webhook_signature(self, raw_payload: bytes, signature_header: str) -> bool:
        raise NotImplementedError

    @abstractmethod
    def parse_webhook_event(self, raw_payload: bytes) -> NormalizedKYCEvent:
        """Raises UnknownEventTypeError if the payload's event type is not
        in this adapter's recognized whitelist."""
        raise NotImplementedError

    @abstractmethod
    def create_applicant(self, member_id: str) -> str:
        """Returns a provider_applicant_id. Requires live provider credentials
        -- see SumsubAdapter's docstring for why this raises in the current
        (pre-procurement-approval) phase."""
        raise NotImplementedError

    @abstractmethod
    def get_verification_url(self, provider_applicant_id: str) -> str:
        raise NotImplementedError


class UnknownEventTypeError(Exception):
    """Raised by a provider adapter when a webhook's event type is not in
    its recognized whitelist. Per Business Owner correction: unknown events
    are rejected explicitly, never silently ignored."""


class InvalidWebhookSignatureError(Exception):
    """Raised when HMAC signature verification fails."""


class ApplicantMappingError(Exception):
    """Raised when a webhook's applicant_id does not map to exactly one
    known, active kyc_verifications record."""


class DuplicateApplicantError(Exception):
    """Raised when a member already has an active (non-terminal) KYC
    verification and a new one is attempted."""


# ---------------------------------------------------------------------------
# Repository interfaces (persistence abstraction -- swappable in-memory vs DB)
# ---------------------------------------------------------------------------

@dataclass
class KYCVerification:
    id: str
    member_id: str
    provider_name: str
    provider_applicant_id: str
    state: KYCState
    created_at: datetime
    updated_at: datetime


@dataclass
class KYCStateTransitionRecord:
    id: str
    kyc_verification_id: str
    from_state: Optional[KYCState]
    to_state: KYCState
    actor_type: str  # "MEMBER" / "VENDOR_WEBHOOK" / "ADMIN"
    actor_id: str
    provider_applicant_id: Optional[str]
    idempotency_key: Optional[str]
    timestamp: datetime


class KYCVerificationRepository(ABC):
    @abstractmethod
    def get_by_id(self, verification_id: str) -> Optional[KYCVerification]:
        raise NotImplementedError

    @abstractmethod
    def get_by_provider_applicant_id(self, provider_name: str, provider_applicant_id: str) -> Optional[KYCVerification]:
        raise NotImplementedError

    @abstractmethod
    def get_active_for_member(self, member_id: str) -> Optional[KYCVerification]:
        """Returns the member's current non-terminal (or most recent) KYC
        verification, or None. Used for duplicate-applicant detection."""
        raise NotImplementedError

    @abstractmethod
    def save(self, verification: KYCVerification) -> None:
        raise NotImplementedError


class KYCStateTransitionRepository(ABC):
    @abstractmethod
    def append(self, transition: KYCStateTransitionRecord) -> None:
        """Append-only: no update()/delete() method exists on this interface
        by design."""
        raise NotImplementedError

    @abstractmethod
    def list_for_verification(self, verification_id: str) -> List[KYCStateTransitionRecord]:
        raise NotImplementedError

    @abstractmethod
    def has_idempotency_key(self, idempotency_key: str) -> bool:
        raise NotImplementedError


class AuditLogWriter(ABC):
    @abstractmethod
    def write(self, event_type: str, payload: Dict[str, Any]) -> None:
        raise NotImplementedError


class MemberActivationPort(ABC):
    """Boundary into the Member module. KYC never touches Commission Engine
    directly or Member's DB tables directly except through this port."""

    @abstractmethod
    def activate_member_transactionally(
        self, member_id: str, kyc_verification_id: str, admin_or_system_actor: str
    ) -> bool:
        """Performs, inside a single DB transaction: member status ACTIVE,
        a new member_status_history row, and an audit record. Returns True
        if committed, False/raises if rolled back. See db_repositories.py
        for the real SQLAlchemy transaction; the in-memory test double here
        simulates the same all-or-nothing contract."""
        raise NotImplementedError


# ---------------------------------------------------------------------------
# In-memory implementations (testing -- mirrors commission_engine's own
# InMemoryUplineProvider / InMemoryRankSnapshotProvider pattern)
# ---------------------------------------------------------------------------

class InMemoryKYCVerificationRepository(KYCVerificationRepository):
    def __init__(self):
        self._by_id: Dict[str, KYCVerification] = {}

    def get_by_id(self, verification_id: str) -> Optional[KYCVerification]:
        return self._by_id.get(verification_id)

    def get_by_provider_applicant_id(self, provider_name: str, provider_applicant_id: str) -> Optional[KYCVerification]:
        for v in self._by_id.values():
            if v.provider_name == provider_name and v.provider_applicant_id == provider_applicant_id:
                return v
        return None

    def get_active_for_member(self, member_id: str) -> Optional[KYCVerification]:
        candidates = [v for v in self._by_id.values() if v.member_id == member_id]
        if not candidates:
            return None
        non_terminal = [v for v in candidates if v.state not in (KYCState.APPROVED, KYCState.REJECTED)]
        if non_terminal:
            return sorted(non_terminal, key=lambda v: v.created_at)[-1]
        return sorted(candidates, key=lambda v: v.created_at)[-1]

    def save(self, verification: KYCVerification) -> None:
        self._by_id[verification.id] = verification


class InMemoryKYCStateTransitionRepository(KYCStateTransitionRepository):
    def __init__(self):
        self._records: List[KYCStateTransitionRecord] = []
        self._idempotency_keys: set = set()

    def append(self, transition: KYCStateTransitionRecord) -> None:
        self._records.append(transition)
        if transition.idempotency_key:
            self._idempotency_keys.add(transition.idempotency_key)

    def list_for_verification(self, verification_id: str) -> List[KYCStateTransitionRecord]:
        return [r for r in self._records if r.kyc_verification_id == verification_id]

    def has_idempotency_key(self, idempotency_key: str) -> bool:
        return idempotency_key in self._idempotency_keys


class InMemoryAuditLogWriter(AuditLogWriter):
    def __init__(self):
        self.entries: List[Dict[str, Any]] = []

    def write(self, event_type: str, payload: Dict[str, Any]) -> None:
        self.entries.append({"event_type": event_type, "payload": payload,
                              "written_at": datetime.now(timezone.utc)})


class InMemoryMemberActivationPort(MemberActivationPort):
    """Test double simulating the transactional all-or-nothing contract.
    `fail_activation` lets tests force a rollback to prove atomicity."""

    def __init__(self):
        self.activated_members: Dict[str, str] = {}  # member_id -> kyc_verification_id
        self.status_history_entries: List[Dict[str, Any]] = []
        self.audit_entries: List[Dict[str, Any]] = []
        self.fail_activation: bool = False

    def activate_member_transactionally(
        self, member_id: str, kyc_verification_id: str, admin_or_system_actor: str
    ) -> bool:
        if self.fail_activation:
            # Simulates a DB transaction rollback: NOTHING is persisted.
            return False
        self.activated_members[member_id] = kyc_verification_id
        self.status_history_entries.append({
            "member_id": member_id, "status": "ACTIVE", "changed_by": admin_or_system_actor,
        })
        self.audit_entries.append({
            "action": "MEMBER_ACTIVATED", "member_id": member_id,
            "kyc_verification_id": kyc_verification_id,
        })
        return True
