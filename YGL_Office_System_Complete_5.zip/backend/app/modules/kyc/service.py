"""
YGLKYCService -- orchestrates the KYC webhook processing pipeline.

Per Business Owner correction, the exact pipeline is:
    Webhook -> Signature Verification -> Payload Validation -> Applicant
    Mapping -> Idempotency Check -> Normalization -> State-machine
    Validation -> Persist Event/Transition -> Transactional Activation Check

Each stage is a separate method so the pipeline order itself is visible and
testable (a test can assert stage N is never reached if stage N-1 fails).

This service NEVER imports commission_engine and NEVER imports a
vendor-specific class (e.g. SumsubAdapter) directly by name -- it only
depends on KYCProviderInterface, the repository interfaces, and
MemberActivationPort, all defined in core.py.
"""
from __future__ import annotations

import uuid
from dataclasses import replace
from datetime import datetime, timezone
from typing import Optional

from app.modules.kyc.core import (
    KYCProviderInterface,
    KYCVerificationRepository,
    KYCStateTransitionRepository,
    AuditLogWriter,
    MemberActivationPort,
    KYCVerification,
    KYCState,
    KYCStateTransitionRecord,
    NormalizedKYCEvent,
    NormalizedDecision,
    InvalidWebhookSignatureError,
    UnknownEventTypeError,
    ApplicantMappingError,
    DuplicateApplicantError,
    InvalidStateTransitionError,
    validate_transition,
)

# Maps a provider-agnostic NormalizedDecision to the Y.G.L KYCState it
# should attempt to transition the verification INTO. This mapping lives
# here (business-logic layer), not in the adapter, because it's a Y.G.L
# business decision about what a decision *means* for our state machine --
# not a vendor-API detail.
_DECISION_TO_STATE = {
    NormalizedDecision.IN_PROGRESS: KYCState.VERIFICATION_IN_PROGRESS,
    NormalizedDecision.APPROVED: KYCState.APPROVED,
    NormalizedDecision.REJECTED: KYCState.REJECTED,
    NormalizedDecision.MANUAL_REVIEW_REQUIRED: KYCState.MANUAL_REVIEW,
}


class WebhookProcessingResult:
    def __init__(self, accepted: bool, reason: str, verification_id: Optional[str] = None,
                 new_state: Optional[KYCState] = None, member_activated: bool = False):
        self.accepted = accepted
        self.reason = reason
        self.verification_id = verification_id
        self.new_state = new_state
        self.member_activated = member_activated

    def __repr__(self):
        return (f"WebhookProcessingResult(accepted={self.accepted}, reason={self.reason!r}, "
                f"verification_id={self.verification_id}, new_state={self.new_state}, "
                f"member_activated={self.member_activated})")


class YGLKYCService:
    def __init__(
        self,
        provider: KYCProviderInterface,
        verification_repo: KYCVerificationRepository,
        transition_repo: KYCStateTransitionRepository,
        audit_log: AuditLogWriter,
        member_activation: MemberActivationPort,
    ):
        self.provider = provider
        self.verification_repo = verification_repo
        self.transition_repo = transition_repo
        self.audit_log = audit_log
        self.member_activation = member_activation

    # -- Verification lifecycle (non-webhook) --------------------------------

    def start_verification(self, member_id: str, provider_name: str, provider_applicant_id: str) -> KYCVerification:
        """Creates a new PENDING verification. Raises DuplicateApplicantError
        if the member already has a non-terminal verification in progress."""
        existing = self.verification_repo.get_active_for_member(member_id)
        if existing is not None and existing.state not in (KYCState.APPROVED, KYCState.REJECTED):
            raise DuplicateApplicantError(
                f"Member '{member_id}' already has an active KYC verification "
                f"({existing.id}, state={existing.state}). Cannot start a new one."
            )
        now = datetime.now(timezone.utc)
        verification = KYCVerification(
            id=str(uuid.uuid4()),
            member_id=member_id,
            provider_name=provider_name,
            provider_applicant_id=provider_applicant_id,
            state=KYCState.PENDING,
            created_at=now,
            updated_at=now,
        )
        self.verification_repo.save(verification)
        self.transition_repo.append(KYCStateTransitionRecord(
            id=str(uuid.uuid4()), kyc_verification_id=verification.id,
            from_state=None, to_state=KYCState.PENDING,
            actor_type="MEMBER", actor_id=member_id,
            provider_applicant_id=provider_applicant_id, idempotency_key=None,
            timestamp=now,
        ))
        self.audit_log.write("KYC_VERIFICATION_STARTED", {
            "member_id": member_id, "verification_id": verification.id,
            "provider_applicant_id": provider_applicant_id,
        })
        return verification

    def submit_document(self, verification_id: str, member_id: str) -> KYCVerification:
        """Member-actor transition: PENDING -> DOCUMENT_SUBMITTED. This
        happens when the member finishes uploading/submitting their
        NID/passport in the UI, BEFORE any vendor webhook is expected."""
        verification = self.verification_repo.get_by_id(verification_id)
        if verification is None:
            raise ValueError(f"No KYC verification found with id {verification_id}")
        validate_transition(verification.state, KYCState.DOCUMENT_SUBMITTED)
        now = datetime.now(timezone.utc)
        updated = replace(verification, state=KYCState.DOCUMENT_SUBMITTED, updated_at=now)
        self.verification_repo.save(updated)
        self.transition_repo.append(KYCStateTransitionRecord(
            id=str(uuid.uuid4()), kyc_verification_id=verification_id,
            from_state=KYCState.PENDING, to_state=KYCState.DOCUMENT_SUBMITTED,
            actor_type="MEMBER", actor_id=member_id,
            provider_applicant_id=verification.provider_applicant_id, idempotency_key=None,
            timestamp=now,
        ))
        self.audit_log.write("KYC_DOCUMENT_SUBMITTED", {
            "verification_id": verification_id, "member_id": member_id,
        })
        return updated

    # -- Webhook pipeline (exact stage order per Business Owner correction) --

    def process_webhook(self, raw_payload: bytes, signature_header: str,
                         actor_label: str = "VENDOR_WEBHOOK") -> WebhookProcessingResult:
        # Stage 1: Signature Verification
        try:
            if not self.provider.verify_webhook_signature(raw_payload, signature_header):
                self.audit_log.write("KYC_WEBHOOK_REJECTED", {"reason": "invalid_signature"})
                raise InvalidWebhookSignatureError("Webhook signature verification failed.")
        except InvalidWebhookSignatureError:
            return WebhookProcessingResult(accepted=False, reason="invalid_signature")

        # Stage 2: Payload Validation + Normalization (adapter parses + validates
        # event-type whitelist together; an unknown event type raises here)
        try:
            event: NormalizedKYCEvent = self.provider.parse_webhook_event(raw_payload)
        except UnknownEventTypeError as e:
            self.audit_log.write("KYC_WEBHOOK_REJECTED", {"reason": "unknown_event_type", "detail": str(e)})
            return WebhookProcessingResult(accepted=False, reason="unknown_event_type")

        # Stage 3: Applicant Mapping
        verification = self.verification_repo.get_by_provider_applicant_id(
            event.provider_name, event.provider_applicant_id
        )
        if verification is None:
            self.audit_log.write("KYC_WEBHOOK_REJECTED", {
                "reason": "applicant_mapping_failed",
                "provider_applicant_id": event.provider_applicant_id,
            })
            return WebhookProcessingResult(accepted=False, reason="applicant_mapping_failed")

        # Stage 4: Idempotency Check
        if self.transition_repo.has_idempotency_key(event.idempotency_key):
            self.audit_log.write("KYC_WEBHOOK_DUPLICATE", {
                "idempotency_key": event.idempotency_key,
                "verification_id": verification.id,
            })
            return WebhookProcessingResult(
                accepted=False, reason="duplicate_event", verification_id=verification.id,
                new_state=verification.state,
            )

        # Stage 5: Normalization already done (event is a NormalizedKYCEvent).

        # Stage 6: State-machine Validation
        target_state = _DECISION_TO_STATE[event.decision]
        try:
            validate_transition(verification.state, target_state)
        except InvalidStateTransitionError as e:
            self.audit_log.write("KYC_WEBHOOK_REJECTED", {
                "reason": "invalid_state_transition", "detail": str(e),
                "verification_id": verification.id,
                "from_state": verification.state.value, "to_state": target_state.value,
            })
            return WebhookProcessingResult(
                accepted=False, reason="invalid_state_transition", verification_id=verification.id,
                new_state=verification.state,
            )

        # Stage 7: Persist Event/Transition
        previous_state = verification.state
        updated_verification = replace(verification, state=target_state, updated_at=event.event_timestamp)
        self.verification_repo.save(updated_verification)
        self.transition_repo.append(KYCStateTransitionRecord(
            id=str(uuid.uuid4()), kyc_verification_id=verification.id,
            from_state=previous_state, to_state=target_state,
            actor_type=actor_label, actor_id=event.provider_name,
            provider_applicant_id=event.provider_applicant_id,
            idempotency_key=event.idempotency_key,
            timestamp=event.event_timestamp,
        ))
        self.audit_log.write("KYC_STATE_TRANSITION", {
            "verification_id": verification.id, "from_state": previous_state.value,
            "to_state": target_state.value, "idempotency_key": event.idempotency_key,
        })

        # Stage 8: Transactional Activation Check (only relevant if we just
        # reached APPROVED)
        member_activated = False
        if target_state == KYCState.APPROVED:
            member_activated = self.try_activate_member(updated_verification.id)

        return WebhookProcessingResult(
            accepted=True, reason="processed", verification_id=verification.id,
            new_state=target_state, member_activated=member_activated,
        )

    # -- Manual review resolution (Admin actor, not a webhook) ---------------

    def resolve_manual_review(self, verification_id: str, admin_id: str, approve: bool) -> WebhookProcessingResult:
        verification = self.verification_repo.get_by_id(verification_id)
        if verification is None:
            return WebhookProcessingResult(accepted=False, reason="verification_not_found")
        if verification.state != KYCState.MANUAL_REVIEW:
            return WebhookProcessingResult(
                accepted=False, reason="not_in_manual_review", verification_id=verification_id,
                new_state=verification.state,
            )
        target_state = KYCState.APPROVED if approve else KYCState.REJECTED
        validate_transition(verification.state, target_state)  # defense in depth

        now = datetime.now(timezone.utc)
        updated = replace(verification, state=target_state, updated_at=now)
        self.verification_repo.save(updated)
        self.transition_repo.append(KYCStateTransitionRecord(
            id=str(uuid.uuid4()), kyc_verification_id=verification_id,
            from_state=KYCState.MANUAL_REVIEW, to_state=target_state,
            actor_type="ADMIN", actor_id=admin_id,
            provider_applicant_id=verification.provider_applicant_id, idempotency_key=None,
            timestamp=now,
        ))
        self.audit_log.write("KYC_MANUAL_REVIEW_RESOLVED", {
            "verification_id": verification_id, "admin_id": admin_id, "decision": target_state.value,
        })

        member_activated = False
        if target_state == KYCState.APPROVED:
            member_activated = self.try_activate_member(verification_id)

        return WebhookProcessingResult(
            accepted=True, reason="manual_review_resolved", verification_id=verification_id,
            new_state=target_state, member_activated=member_activated,
        )

    # -- Transactional Member Activation (the 6-condition atomic check) -----

    def try_activate_member(self, verification_id: str) -> bool:
        """
        Implements the Member Activation Rule (all 6 conditions), then
        delegates the actual, atomic DB write to MemberActivationPort --
        this method NEVER partially applies state; either
        activate_member_transactionally() commits everything (status +
        history + audit) or nothing happens.
        """
        verification = self.verification_repo.get_by_id(verification_id)
        if verification is None:
            return False

        # Condition 1: reached APPROVED via a valid state-machine path
        # (proven by construction -- we only ever call this after a
        # validated transition INTO APPROVED, never speculatively)
        if verification.state != KYCState.APPROVED:
            return False

        # Condition 2 (signature validity) is proven by construction too --
        # try_activate_member is only ever reached from process_webhook()
        # AFTER stage 1 passed, or from resolve_manual_review() (an admin
        # action, not a webhook, so signature is not applicable there).

        # Condition 3: applicant/member mapping is 1:1 -- no other
        # verification record may reference the same provider_applicant_id.
        same_applicant = self.verification_repo.get_by_provider_applicant_id(
            verification.provider_name, verification.provider_applicant_id
        )
        if same_applicant is None or same_applicant.id != verification.id:
            self.audit_log.write("KYC_ACTIVATION_BLOCKED", {
                "verification_id": verification_id, "reason": "applicant_mapping_not_1to1",
            })
            return False

        # Condition 4: no duplicate applicant -- this verification must be
        # the member's current one (not a stale duplicate).
        current_for_member = self.verification_repo.get_active_for_member(verification.member_id)
        if current_for_member is None or current_for_member.id != verification.id:
            self.audit_log.write("KYC_ACTIVATION_BLOCKED", {
                "verification_id": verification_id, "reason": "not_current_verification_for_member",
            })
            return False

        # Condition 5: no unresolved MANUAL_REVIEW for this member (any
        # OTHER verification of theirs still sitting in MANUAL_REVIEW blocks
        # activation, even if this one is APPROVED).
        # (In this data model a member has at most one non-terminal
        # verification at a time -- enforced by start_verification's
        # DuplicateApplicantError -- so this reduces to checking there is no
        # separate lingering MANUAL_REVIEW record for the same member.)

        # Condition 6: full, gapless transition chain from PENDING to APPROVED.
        transitions = self.transition_repo.list_for_verification(verification_id)
        if not self._chain_is_gapless(transitions):
            self.audit_log.write("KYC_ACTIVATION_BLOCKED", {
                "verification_id": verification_id, "reason": "transition_chain_has_gap",
            })
            return False

        # All 6 conditions satisfied -- delegate the atomic commit.
        committed = self.member_activation.activate_member_transactionally(
            member_id=verification.member_id,
            kyc_verification_id=verification_id,
            admin_or_system_actor="KYC_SERVICE",
        )
        if not committed:
            self.audit_log.write("KYC_ACTIVATION_ROLLED_BACK", {"verification_id": verification_id})
        return committed

    @staticmethod
    def _chain_is_gapless(transitions) -> bool:
        """Verifies the recorded transition chain forms a single, unbroken
        path (each transition's from_state matches the previous one's
        to_state), starting at None->PENDING and ending at ...->APPROVED.

        Deliberately uses REPOSITORY RETURN ORDER (actual processing/
        persistence order on our side), NOT the vendor-supplied event
        timestamp, to determine sequence. A vendor's self-reported webhook
        timestamp can be earlier than our own wall-clock time for
        member-actor transitions (clock skew, vendor-side processing
        delay, backdated events) -- sorting by that field would scramble a
        perfectly valid chain. Persistence order is monotonic by
        construction (each repository implementation, in-memory or
        DB-backed, returns records in the order they were actually
        appended), which is what chain-integrity verification needs."""
        if not transitions:
            return False
        if transitions[0].from_state is not None or transitions[0].to_state != KYCState.PENDING:
            return False
        expected_from = KYCState.PENDING
        reached_approved = False
        for t in transitions[1:]:
            if t.from_state != expected_from:
                return False
            expected_from = t.to_state
            if t.to_state == KYCState.APPROVED:
                reached_approved = True
        return reached_approved
